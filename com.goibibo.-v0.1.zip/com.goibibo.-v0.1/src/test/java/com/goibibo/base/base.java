package com.goibibo.base;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

public class base {

	protected static WebDriver driver;
	protected static ExtentTest testLog;
	protected static ExtentReports extentReporter;

	@BeforeTest
	@Parameters({ "browser", "domain" })
	public void beforeSuite(String browser, String domain) {
		if (browser.equalsIgnoreCase("chrome")) {
			System.setProperty("webdriver.chrome.driver", ".//chromedriver.exe");
			driver = new ChromeDriver(new ChromeOptions().addArguments("start-maximized"));
		} else if (browser.equalsIgnoreCase("firefox")) {
			System.setProperty("webdriver.gecko.driver", ".//geckodriver.exe");
			driver = new FirefoxDriver(new FirefoxOptions().addArguments("start-maximized"));
		}

		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.get(domain);
		extentReporter = new ExtentReports();
		extentReporter.attachReporter(new ExtentHtmlReporter("ViaComReport0.html"));
	}

	@AfterTest
	public void afterTest() {
	}

}
