package com.goibibo.base;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class BasePOM {
	WebDriver driver;
	WebDriverWait wait;
	Actions action;

	public BasePOM(WebDriver driver) {
		this.driver = driver;
		action = new Actions(driver);
		wait = new WebDriverWait(driver, 20);
	}
}
