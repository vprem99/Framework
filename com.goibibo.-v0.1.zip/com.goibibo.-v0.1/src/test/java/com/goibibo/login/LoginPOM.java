package com.goibibo.login;

import org.openqa.selenium.WebDriver;

import com.goibibo.base.BasePOM;

public class LoginPOM extends BasePOM{

	public LoginPOM(WebDriver driver) {
		super(driver);
	}

}
