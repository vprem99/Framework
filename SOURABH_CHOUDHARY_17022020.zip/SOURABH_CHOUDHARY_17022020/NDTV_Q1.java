package Sourabh_Choudhary_17022020;

import org.testng.annotations.Test;

import HelperFunction.Base;

import org.testng.annotations.BeforeMethod;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;

public class NDTV_Q1 extends Base {
  @Test
  public void f() throws Exception {
	  
	  Actions action = new Actions(driver);
	  
	  //Second point
	  List<WebElement> list_of_href_of_topstories = driver.findElements(By.xpath("/html/body/div[5]/div/div[1]/div[1]/div/div[1]/div[2]/div[1]/div[2]/div[1]/div/div[*]/h1/a"));
	  for(WebElement listt : list_of_href_of_topstories) {
		  System.out.println(listt.getAttribute("href"));
	  }
	 
	  //Third point
	  WebElement w1 = driver.findElement(By.xpath("/html/body/div[3]/div/div/div/div[2]/div[1]/ul/li[3]/a"));
	  Assert.assertEquals(w1, "Latest", "Latest is not present");
	  
	  //Fourth Point
	  action.contextClick().click(driver.findElement(By.xpath("/html/body/div[3]/div/div/div/div[2]/div[1]/ul/li[3]/a"))).perform();
	  driver.switchTo().window(driver.getWindowHandles().toArray()[1].toString());
	  System.out.println(driver.getTitle());
	  
	  //Fifth Point	  
	  List<WebElement> list_of_href_of_second_page = driver.findElements(By.xpath("//*[@id=\"ins_storylist\"]/ul/li[*]/div[2]/div[1]/a"));
	  for (int i = 0 ; i<3; i++)	{
		  for(WebElement list2 : list_of_href_of_second_page) {
		  
			  System.out.println(list2.getAttribute("href"));
		  }
	  }
	  TakeScreenShot(".\\\\first_screenshot.png");
	  
	  //Sixth Point
	  System.out.println(driver.getTitle());
	 
	
	  
  }
  @BeforeMethod
  public void beforeMethod() {
	  launchBrowser("chrome", false);
	  //First Point
	  driver.get(" https://www.ndtv.com/business");
  }

  @AfterMethod
  public void afterMethod() throws Exception {
	  Quit();
  }

}
