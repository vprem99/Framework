package Sourabh_Choudhary_17022020;

import org.testng.annotations.Test;

import HelperFunction.Base;

import org.testng.annotations.BeforeMethod;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.AfterMethod;

public class NDTV_Q3 extends Base{
  @Test
  public void f() throws Exception {
	  Actions action = new Actions(driver);
	  WebElement sensex_value = driver.findElement(By.xpath("/html[1]/body[1]/div[1]/header[1]/header[1]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[1]/a[3]/span[1]/span[1]"));
	  System.out.println(sensex_value.getText());
	  WebElement change = driver.findElement(By.xpath("//*[@id=\"header-data\"]/a[3]/span/span[2]/span"));
	  System.out.println(change);
	  WebElement perc_change = driver.findElement(By.xpath("//*[@id=\\\"header-data\\\"]/a[3]/span/span[2]/text()"));
	  System.out.println(perc_change);
	  
	  driver.findElement(By.xpath("//a[@class='col sensex pager']//h5[contains(text(),'NIFTY50')]")).click();
	  
	  JavascriptExecutor js = (JavascriptExecutor)driver;
	  js.executeScript("arguments[0].scrollIntoView()", driver.findElement(By.xpath("//*[@id='Alphabetical']")));
	  driver.findElement(By.xpath("//*[@id=\"Alphabetical\"]")).click();
	  
	  action.moveToElement(driver.findElement(By.xpath("//*[@id=\"peerlist1\"]/li[1]/a"))).perform();
	  
	  TakeScreenShot(".\\First company in alphabetical order.png");
	  WebElement company_name = driver.findElement(By.xpath("//div[@class='sub-output']//li[1]/a"));
	  System.out.println(company_name.getText());
	  WebElement percentage = driver.findElement(By.xpath("//div[@class='sub-output']//li[1]/a/text()"));
	  System.out.println(company_name.getText());
	  
	  List<WebElement> list1 =driver.findElements(By.xpath("//*[@id=\"peerlist2\"]/li[*]/a"));
	  for(WebElement ww : list1) {
		  System.out.println(ww.getAttribute("title"));
	  }
	
  }
  @BeforeMethod
  public void beforeMethod() {
	  launchBrowser("chrome", true);
	  
	  // First Point
	  driver.get(" https://www.ndtv.com/business");
  }

  @AfterMethod
  public void afterMethod() throws Exception {
	  Quit();
  }

}
