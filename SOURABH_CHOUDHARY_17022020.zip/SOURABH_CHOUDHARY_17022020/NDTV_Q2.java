package Sourabh_Choudhary_17022020;

import org.testng.annotations.Test;

import HelperFunction.Base;

import org.testng.annotations.BeforeMethod;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;

public class NDTV_Q2 extends Base{
  @Test
  public void f() throws Exception {
	  Actions action = new Actions(driver);
	  //Second Point
	  TakeScreenShot(".\\site_opened.png");
	  
	  //Third Point
	  action.click(driver.findElement(By.id("type"))).perform();
	  action.click(driver.findElement(By.linkText("Stock"))).perform();
	  TakeScreenShot(".\\Stock_screenshot.png");
	  
	  //Fouth Point
	  WebElement search = driver.findElement(By.id("search"));
	  search.sendKeys("Infosys");
	  driver.findElement(By.xpath("//*[@id=\"header\"]/div/div[2]/a")).click();
	  //Fifth Point
	  action.click(driver.findElement(By.xpath("//*[@id=\"insidetab\"]/ul/li[3]/a"))).perform();
	  
	  WebElement video= driver.findElement(By.xpath("//*[@id=\"videoresults\"]/div[1]/div/span"));
	  String video_result  = video.getText();
	  
	  String no_of_videos= video_result.substring(12, 15);
	  int result = Integer.parseInt(no_of_videos);
	  System.out.println(result);
	  //Sixth Point
	  Assert.assertTrue(result>1, "result is less not greater than 1");
	  
	  //Seventh Point
	  WebElement first_video = driver.findElement(By.xpath("//*[@id=\"Related\"]/ul[1]/li[1]/p[2]/a/strong"));
	  String video_url = first_video.getAttribute("href");
	  System.out.println(video_url);
	  
	  
	  //Eighth Point
	  driver.navigate().to(video_url);
	  
	  
	  
  }
  @BeforeMethod
  public void beforeMethod() {
	  launchBrowser("chrome", true);
	  
	  // First Point
	  driver.get(" https://www.ndtv.com/business");
  }

  @AfterMethod
  public void afterMethod() throws Exception {
	  Quit();
  }

}
