package HelperFunction;

import java.io.File;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.io.FileHandler;
import org.openqa.selenium.support.PageFactory;

public class Base {
	public WebDriver driver;

	// at headless pass false. only for headless execution pass true
	public void launchBrowser(String BrowserName, boolean Headless) {
		BrowserName.toUpperCase();
		if (BrowserName.equalsIgnoreCase("CHROME")) {
			ChromeOptions c1 = new ChromeOptions();
			c1.setHeadless(Headless);
			String DPath = ".\\Drivers\\chromedriver.exe";
			System.setProperty("webdriver.chrome.driver", DPath);
			driver = new ChromeDriver(c1);
			PageFactory.initElements(driver, this);
			System.out.println("Browser Launched Successsfully ......  ");
			driver.manage().window().maximize();
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		} else if (BrowserName.equalsIgnoreCase("FIREFOX")) {
			FirefoxOptions c1 = new FirefoxOptions();
			c1.setHeadless(Headless);
			String DPath = ".\\Drivers\\geckodriver.exe";
			System.setProperty("webdriver.gecko.driver", DPath);
			driver = new FirefoxDriver(c1);
			PageFactory.initElements(driver, this);
			System.out.println("Browser Launched Successsfully ......  ");
			driver.manage().window().maximize();
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		}
	}
	public By getElementForKey(String Locator) {
		  //name:=q
		  String locatorType= Locator.split(":=")[0];  //name
		  String locatorValue=Locator.split(":=")[1];  // q  
		  if (locatorType.equalsIgnoreCase("id"))
			  return By.id(locatorValue);
		  else if (locatorType.equalsIgnoreCase("link"))
			  return By.linkText(locatorValue);
		  else if (locatorType.equalsIgnoreCase("name"))
			  return By.name(locatorValue);
		  else if (locatorType.equalsIgnoreCase("xpath"))
			  return By.xpath(locatorValue);
		  else
			  return null;	  
	  }
	public void TakeScreenShot(String filenamewithpath) throws Exception {
		TakesScreenshot t1 = (TakesScreenshot) driver;
		File src = t1.getScreenshotAs(OutputType.FILE);
		FileHandler.copy(src, new File(filenamewithpath));
	}

	public void Quit() throws InterruptedException {
		Thread.sleep(5000);
		driver.quit();
	}
	
}
