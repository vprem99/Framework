package Sourabh_Choudhary_17022020;



import org.testng.annotations.Test;

import HelperFunction.Base;
import HelperFunction.ExcelReader;

import org.testng.annotations.DataProvider;
import org.testng.annotations.BeforeTest;
import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.AfterTest;

public class NDTV_Q5 extends Base {
  @Test(dataProvider = "dp")
  public void f( String s,String s1) {
	  if(s.equalsIgnoreCase("Latest")) {
		  Assert.assertEquals(driver.findElement(By.xpath("/html/body/div[3]/div/div/div/div[2]/div[1]/ul/li[3]/a")).getAttribute("href"),s1);
	  }else if(s.equalsIgnoreCase("Markets")) {
		  Assert.assertEquals(driver.findElement(By.xpath("/html/body/div[3]/div/div/div/div[2]/div[1]/ul/li[4]/a")).getAttribute("href"),s1);
	  }else if (s.equalsIgnoreCase("Money")) {
		  Assert.assertEquals(driver.findElement(By.xpath("/html/body/div[3]/div/div/div/div[2]/div[1]/ul/li[7]/a")).getAttribute("href"),s1);
	  }
  }

  @DataProvider
  public Object[][] dp() {
	  ExcelReader e1 = new ExcelReader("C:\\Users\\vshadmin\\Downloads\\datadriven_ndtv.xlsx");
	  String[][] s1 = e1.getAllData("Sheet1",3 ,2);
	  return s1;
			  
  }
  @BeforeTest
  public void beforeTest() {
	  launchBrowser("chrome", false);
	  //First Point
	  driver.get("https://www.ndtv.com/business");
	  
  }

  @AfterTest
  public void afterTest() throws InterruptedException {
	  Quit();
  }
}

