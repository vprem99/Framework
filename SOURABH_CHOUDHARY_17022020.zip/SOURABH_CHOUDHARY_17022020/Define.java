package Sourabh_Choudhary_17022020;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

public class Define {
	WebDriver driver;
	public Define(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	@FindBy (xpath = "//*[@id='RHS_WYSIWYG']/div/div/a")List<WebElement> list1;
	@FindBy (xpath = "/html/body/div[5]/div/div[3]/div/div/div/div/div[2]/div[4]/ul/li[*]/a")List<WebElement> list2;
	public void a() {
		for(WebElement first : list1) {
			System.out.println(first.getAttribute("href"));
		}
		
	}
	public void b() {
		for(WebElement first : list2) {
			System.out.println(first.getAttribute("href"));
		}	
	}
	public void c() {
		for(int i = 0; i<list1.size();i++) {
			for(int j = 0; j<list2.size();j++) {
				 Assert.assertEquals(list1.get(i).getAttribute("href"),list2.get(j).getAttribute("href"));
			}	
		}
	}

}
