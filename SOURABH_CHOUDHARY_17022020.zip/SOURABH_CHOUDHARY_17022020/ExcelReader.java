package HelperFunction;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.util.List;
import java.util.Set;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;




public class ExcelReader {

	FileInputStream ip = null; 
	public Workbook wb;
	public ExcelReader(String locationWithFileName) {
	
		try {
			ip = new FileInputStream(locationWithFileName);
			
			if(locationWithFileName.endsWith(".xls")) {
				wb = new HSSFWorkbook(ip);
			}else if(locationWithFileName.endsWith(".xlsx")) {
				wb = new XSSFWorkbook(ip);	
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public String getCellData(String sheetName, int row, int col) {
		String data = wb.getSheet(sheetName).getRow(row).getCell(col).toString();
		return data;
	}
	
	public int getRowNum(String sheetName) {
		int data = wb.getSheet(sheetName).getLastRowNum();
		return data;
	}
	
	
	public String[][] getAllData(String sheetName,int row,int col) {
		String[][] data = new String[row][col];
		for(int i=0;i<row;i++) {
			for(int j=0;j<col;j++) {
				data[i][j] = wb.getSheet(sheetName).getRow(i).getCell(j).toString();
			}
		}
		return data;
	}
	 public void WriteInFile(String FileWithPath,String sheetName,int row,int col) throws Exception {
		  
		  FileOutputStream ostream = new FileOutputStream(FileWithPath);
			String[][] s1 = new String[row][col];
			s1 =getAllData(sheetName, row, col);	
		  Sheet s = wb.getSheet(sheetName);
		  for(int i = 0;i<row;i++) {
			 // Row row1 = s.createRow(i);
			  for(int j = 0;j<col;j++) {
				  s.getRow(i).createCell(j).setCellValue(s1[i][j]);
			  }
		  }
		  //writing in single row.
//		  s.getRow(row).createCell(col).setCellValue(s1[row][col]);

		  wb.write(ostream);
		  ostream.close();
	  }
}