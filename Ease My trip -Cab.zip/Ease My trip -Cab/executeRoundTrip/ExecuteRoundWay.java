package executeRoundTrip;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import cabRoundTripPOM.CabRoundWaySearch;
import cabRoundTripPOM.CabRoundWayTraveller;
import loginregisterpom.LoginFactory;
import loginregisterpom.Logout;
import util.Base;

public class ExecuteRoundWay extends Base
{
	@Test(priority=1,dataProvider="LoginData")
	public void LoginTest (String UN,String PWD,String source,String destination, String FirstName,String LastName,String PickUpAdd,String DropAdd,String Email,String Mobile) throws Exception 
	{
		
		LoginFactory LF=new LoginFactory(driver);
		
		LF.Login( UN,PWD);
		CabRoundWaySearch crs=new CabRoundWaySearch(driver);
		crs.cabRoundWaySearch( source,destination);			
		
		  CabRoundWayTraveller details = new CabRoundWayTraveller(driver);
			details.cabRoundWayTraveller(FirstName, LastName,PickUpAdd,DropAdd,Email,Mobile);
			
			driver.get("https://www.easemytrip.com/");
	}
	
@DataProvider
	public Object[][] LoginData() throws Exception
	{
		Object data[][]=excel.MyDataProvider("RoundWayCab",10);
		return data;
	}
	
/*	@Test(dataProvider="CabRoundWay", priority=2)
		public void cabroundsearch(String source,String destination, String FirstName,String LastName,String PickUpAdd,String DropAdd,String Email,String Mobile) throws Exception
		{
			
		}
		@DataProvider
		public Object[][] CabRoundWay() throws Exception
		{
			Object data[][]=excel.MyDataProvider("RoundSearch", 8);
			return data;
		}*/
		
//		@Test(priority=3)
//		public void logout() throws Exception
//		{
//			Logout log=new Logout(driver);
//			log.logout();
//		}
	
		
		@AfterMethod
		public void aftermethod(ITestResult result)
		{
			if (result.getStatus()==ITestResult.FAILURE)
			{
				System.out.println("Test Failed");
				Key.getScreenShot(result.getName());
				
			}
			else
			{
				System.out.println("Test pass");
			}
		}
}

