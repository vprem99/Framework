package testExecution;



import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import cabOneWayPOM.CabOneWaySearch;
import loginregisterpom.LoginFactory;
import cabOneWayPOM.*;
import util.Base;


public class Execute extends Base

{
		@Test(dataProvider="OneWayCab")
		public void cabOneWay(String UN,String PWD,String source,String destination,String FirstName,String LastName,String PickUpAdd,String DropAdd,String Email,String Mobile) throws Exception
		{
			
			LoginFactory LF=new LoginFactory(driver);
			LF.Login( UN,PWD);
		 
			CabOneWaySearch cos=new CabOneWaySearch(driver);
			cos.cabOneWaySearch( source,destination);
			
			FilterOneWay filterCab=new FilterOneWay(driver);
			filterCab.filter( source,destination);
			
			Travellersdetails details = new Travellersdetails(driver);
			details.travellersDetails(FirstName, LastName,PickUpAdd,DropAdd,Email,Mobile);
			
			driver.get("https://www.easemytrip.com/");
			
		}
		@DataProvider
		public Object[][] OneWayCab() throws Exception
		{
			Object data[][]=excel.MyDataProvider("OneWayCab",10);
			return data;
		}
	
		
		@AfterMethod
		public void aftermethod(ITestResult result)
		{
			if (result.getStatus()==ITestResult.FAILURE)
		{
		System.out.println("Test Failed");
		Key.getScreenShot(result.getName());
		
		}
			else
			{
				System.out.println("Test pass");
			}
}
		
		
}
