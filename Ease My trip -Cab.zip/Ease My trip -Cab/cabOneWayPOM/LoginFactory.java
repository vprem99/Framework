package cabOneWayPOM;



import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import loginregisterpom.Factory;


public class LoginFactory extends Factory {
	public LoginFactory(WebDriver iDriver)
	{
		super(iDriver);
	}

	public void Login (String username,String Password) throws Exception
	{
	
		WebElement ele = driver.findElement(property.getElement("HOVER1"));

		Actions action = new Actions(driver);

		action.moveToElement(ele).perform();
		Thread.sleep(2000);

		driver.findElement(property.getElement("SIGN_IN")).click();
		WebDriverWait wt=new WebDriverWait(driver, 20);
		wt.until(ExpectedConditions.visibilityOf(driver.findElement(property.getElement("EMAIL_BASIC"))));
		driver.findElement(property.getElement("EMAIL_BASIC")).sendKeys(username);;
		driver.findElement(property.getElement("PASSWORD_BASIC")).sendKeys(Password);;
		driver.findElement(property.getElement("LOGIN")).click();
		
		
	}
}
