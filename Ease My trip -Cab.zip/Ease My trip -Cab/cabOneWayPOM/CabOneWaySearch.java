package cabOneWayPOM;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import loginregisterpom.Factory;

public class CabOneWaySearch extends Factory {
	public CabOneWaySearch(WebDriver iDriver)
	{
		super(iDriver);

	}

	public void cabOneWaySearch(String Source,String Destination) throws Exception

	{
		WebDriverWait wt=new WebDriverWait(driver, 20);
		wt.until(ExpectedConditions.visibilityOf(driver.findElement(property.getElement("E_cab"))));
		
		driver.findElement(property.getElement("E_cab")).click();


		Actions action= new Actions(driver);
		driver.findElement(property.getElement("E_SourceCity")).click();
		new WebDriverWait(driver, 20).until(ExpectedConditions.visibilityOfElementLocated(By.id("ddlSource")));
		driver.findElement(property.getElement("E_SourceCity")).sendKeys(Source);
		

		WebElement E=driver.findElement(By.xpath("//*[contains(text(),'"+Source+"')]"));
		action.moveToElement(E).click(E).perform();

		new WebDriverWait(driver,20).until(ExpectedConditions.visibilityOfElementLocated(By.id("ddlDestination")));
		driver.findElement(property.getElement("E_DestinationCity")).click();
		driver.findElement(property.getElement("E_DestinationCity")).sendKeys(Destination);
		WebElement E1=driver.findElement(By.xpath("//*[contains(text(),'"+Destination+"')]"));
		action.moveToElement(E1).click(E1).perform();
		driver.findElement(By.id("txtDate")).click();	
		//driver.findElement(property.getElement("E_Date")).click();
		//driver.findElement(By.xpath("//li[contains(@id,'20/04/2019')]")).click();
	
		//driver.findElement(By.xpath("//input[@id='txtDate']")).click();
		driver.findElement(By.linkText("27")).click();

		driver.findElement(property.getElement("E_PickupTime")).click();

		new Select(driver.findElement(property.getElement("E_PickupTime"))).selectByIndex(2);

		driver.findElement(property.getElement("E_Search")).click();
		
		Thread.sleep(3000);
/*		
		Assert.assertEquals(driver.getTitle(), "Best Cab Service at Lowest Fares at EaseMyTrip.com");
		System.out.println("Cab filter and Booknow page is opened successfully");
	*/
		try 
		{
			Thread.sleep(5000);
		}
		catch (InterruptedException e)
		{
			
			e.printStackTrace();
		}



	}
}


