package cabRoundTripPOM;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import loginregisterpom.Factory;

public class CabRoundWaySearch extends Factory {
	public CabRoundWaySearch(WebDriver iDriver)
	{
		super(iDriver);

	}

	public void cabRoundWaySearch(String Source,String Destination) throws Exception
	//,String Date,String PickUpTime,String Time)
	{
		//driver.findElement(property.getElement("C_CabIcon")).click();
		
		WebDriverWait wt=new WebDriverWait(driver, 20);
		wt.until(ExpectedConditions.visibilityOf(driver.findElement(property.getElement("E_cab"))));
		driver.findElement(property.getElement("C_cab")).click();
		Thread.sleep(3000);

		Thread.sleep(3000);
		driver.findElement(By.id("radio2")).click();
		Thread.sleep(3000);

		
		Actions action= new Actions(driver);
		driver.findElement(property.getElement("C_Source")).click();
		new WebDriverWait(driver, 20).until(ExpectedConditions.visibilityOfElementLocated(By.id("ddlSource")));
		driver.findElement(property.getElement("C_Source")).sendKeys(Source);
		WebElement E=driver.findElement(By.xpath("//*[contains(text(),'"+Source+"')]"));
		action.moveToElement(E).click(E).perform();

		new WebDriverWait(driver,20).until(ExpectedConditions.visibilityOfElementLocated(By.id("ddlDestination")));
		driver.findElement(property.getElement("C_Destination")).click();
		driver.findElement(property.getElement("C_Destination")).sendKeys(Destination);
		WebElement E1=driver.findElement(By.xpath("//*[contains(text(),'"+Destination+"')]"));
		action.moveToElement(E1).click(E1).perform();


		driver.findElement(By.id("txtDate")).click();
		driver.findElement(property.getElement("C_Date")).click();
		//driver.findElement(By.xpath("//li[contains(@id,'20/04/2019')]")).click();
		//driver.findElement(By.xpath("//input[@id='txtDate']")).click();
		driver.findElement(By.linkText("27")).click();
		Thread.sleep(4000);
		
         driver.findElement(By.id("txtDate")).click();
		driver.findElement(property.getElement("C_Returndate")).click();
		driver.findElement(By.linkText("28")).click();

		Thread.sleep(4000);
		driver.findElement(property.getElement("C_Pickuptiming")).click();
		Thread.sleep(4000);
		new Select(driver.findElement(property.getElement("C_Pickuptiming"))).selectByIndex(1);
		//new Select(driver.findElement(property.getElement("E_PickupTime"))).selectByIndex(1);
		Thread.sleep(4000);
		driver.findElement(property.getElement("C_Cab_Search")).click();
		Thread.sleep(2000);
		
		
		driver.findElement(property.getElement("C_CabType")).click();
		Thread.sleep(2000);
		driver.findElement(property.getElement("C_AC")).click();
		//Thread.sleep(2000);
		/*driver.findElement(property.getElement("C_PersonType")).click();
		Thread.sleep(2000);
		driver.findElement(property.getElement("C_SelectPersonType")).click();
		Thread.sleep(2000);
		driver.findElement(property.getElement("C_Baggage")).click();
		Thread.sleep(2000);
		driver.findElement(property.getElement("C_SelectBaggageType")).click();
		Thread.sleep(2000);*/
		driver.findElement(property.getElement("C_BookNow")).click();
		Thread.sleep(3000);


		try 
		{
			Thread.sleep(5000);
		}
		catch (InterruptedException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}



	}
}