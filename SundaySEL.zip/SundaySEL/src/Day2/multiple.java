package Day2;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class multiple {

	public static void main(String[] args) throws InterruptedException 
	{
		System.setProperty("webdriver.gecko.driver", "/home/lab01-04/Desktop/SeleniumJars1/geckodriver");
		WebDriver w=new FirefoxDriver();// It start firefox
		w.get("http://naukri.com");
		String PID=w.getWindowHandle();  // parent ID
		
		
		Object[] CID=w.getWindowHandles().toArray();  // All window id including Parent
	
		for(int i=0;i<CID.length;i++)
		{
			System.out.println(CID[i].toString());

			if(!CID[i].toString().equals(PID))
			{
				w.switchTo().window(CID[i].toString());
				System.out.println(w.getTitle()+" Closed");
				w.close();
				Thread.sleep(3000);

			}
			
	}
		Thread.sleep(3000);
		w.quit();
	}

}
