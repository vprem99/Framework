package Day2;

import java.io.FileInputStream;

import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Reading 
{
	public static void main(String[] args) throws Exception
	{
//Workbook> sheet > Cells
//.xls    > HSSF
//.xlsx   > XSSF
		
		FileInputStream IP=new FileInputStream("/home/lab01-04/Desktop/data.xls");
		HSSFWorkbook wb=new HSSFWorkbook(IP);
		HSSFSheet s=wb.getSheet("Sheet1");
		System.setProperty("webdriver.gecko.driver", "/home/lab01-04/Desktop/SeleniumJars1/geckodriver");
		WebDriver w=new FirefoxDriver();// It start firefox
		
		for(int i=0;i<=s.getLastRowNum();i++)
		{
		String A=s.getRow(i).getCell(0).toString();
		String B=s.getRow(i).getCell(1).toString();

		System.out.print(A+" ");
		System.out.println(B);
		
		w.get("http://172.168.1.45/mantisbt");
		w.findElement(By.cssSelector("input[type='text']")).sendKeys(A);
		w.findElement(By.cssSelector("input[type='password']")).sendKeys(Keys.ESCAPE);
		w.findElement(By.cssSelector("input[type='password']")).sendKeys(B);
		w.findElement(By.cssSelector("input.button")).click();
		if(w.getTitle().contains("My View"))
		{
		w.findElement(By.linkText("Logout")).click();
		System.out.println("Login Done");
		}
		else
		{
			System.out.println("Login Fail");
			
		}
		}
		w.quit();
	}
}                                                                               
