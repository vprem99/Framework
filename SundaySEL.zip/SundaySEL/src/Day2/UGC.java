package Day2;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;

public class UGC 
{
	public static void main(String[] args) 
	{
		System.setProperty("webdriver.chrome.driver", "/home/lab01-04/Desktop/SeleniumJars1/chromedriver");
		WebDriver w=new ChromeDriver();// It start firefox
		Actions A=new Actions(w);
		
		w.get("http://ugc.ac.in");
		w.findElement(By.cssSelector("a.twoyears-close-btn")).click();
		A.moveToElement(w.findElement(By.linkText("Universities"))).perform();
		
		A.moveToElement(w.findElement(By.linkText("Central Universities"))).click().perform();
		
		
		
		
		
		

	}
}
