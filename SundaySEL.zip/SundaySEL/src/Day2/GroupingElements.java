package Day2;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

public class GroupingElements 
{
	public static void main(String[] args)
	{

		System.setProperty("webdriver.gecko.driver", "/home/lab01-04/Desktop/SeleniumJars1/geckodriver");
		WebDriver w=new FirefoxDriver();// It start firefox
		
		w.get("http://newtours.demoaut.com");
		
		List<WebElement> ls=w.findElements(By.tagName("a"));
		
		int sz=ls.size();
		
		System.out.println("Total Links are "+sz);

		for(int i=0;i<sz;i++)
		{
			String A=ls.get(i).getText();
			ls.get(i).click();;
			System.out.println(w.getCurrentUrl());
			if(w.getTitle().contains("Under"))
			{
				System.out.println(A+" is Under Construction");

			}
			else
			{
				System.out.println(A+" is Working");

			}
			w.navigate().back();
			ls=w.findElements(By.tagName("a"));
			
		}
			w.quit();
		
	}
}
