package NG;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class FirstNG 
{
	WebDriver w;
  @Test(priority=1)
  public void TitleTest() 
  {
	  w.get("http://172.168.1.45/mantisbt");
	  Assert.assertEquals(w.getTitle(), "MantisBT");
  }
  
  @Test(priority=2)
  public void UNTest() 
  {
	  WebElement E=w.findElement(By.name("username"));
	  /*E.isDisplayed();
	  w.findElement(By.name("username")).isEnabled();
	  w.findElement(By.name("username")).getAttribute("size");
	  */
	 Assert.assertEquals(E.isDisplayed(), true);
	Assert.assertEquals(E.isEnabled(), true);
	 Assert.assertEquals(E.getAttribute("size"), "32","Size not Match");

	  
  }
 
  @BeforeTest
  public void beforeTest()   // Pre-Condition
  {
	  System.setProperty("webdriver.gecko.driver", "/home/lab01-04/Desktop/SeleniumJars1/geckodriver");
	  w=new FirefoxDriver();
  }

  @AfterTest
  public void afterTest()
  {
	  w.quit();
  }

}
