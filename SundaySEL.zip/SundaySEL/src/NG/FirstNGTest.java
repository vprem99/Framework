package NG;

import java.net.URL;


import org.openqa.selenium.By;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class FirstNGTest {
 WebDriver w;
	
	@Test(dataProvider = "dp")
  public void f(String n, String s) 
  {
		  w.get("http://172.168.1.45/mantisbt");
		  w.findElement(By.name("username")).sendKeys(n);
		  w.findElement(By.name("password")).sendKeys(s);
		  w.findElement(By.className("button")).click();
		  w.findElement(By.linkText("Logout")).click();
  }

  @DataProvider
  public Object[][] dp() 
  {
	  Object data[][]=new Object[4][2];
	  data[0][0]="tester99";
	  data[0][1]="tester99";
	  data[1][0]="ttl99";
	  data[1][1]="ttlhhh99";
	  data[2][0]="dtl99";
	  data[2][1]="dtl99";
	  data[3][0]="dev99";
	  data[3][1]="dev99";	  
  return data;
  }
   
  @BeforeTest
  @Parameters("node")
  public void beforeTest(String node) throws Exception  // Pre-Condition
  {
	  DesiredCapabilities dc=	DesiredCapabilities.firefox();
		dc.setPlatform(Platform.LINUX);
		dc.setBrowserName("firefox");
		 w=new RemoteWebDriver(new URL(node),dc);
		
  }

  @AfterTest
  public void afterTest()
  {
	  w.quit();
  }

}
