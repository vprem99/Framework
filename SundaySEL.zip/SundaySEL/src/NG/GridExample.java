package NG;

import java.net.URL;

import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

public class GridExample {

	public static void main(String[] args) throws Exception
	{
	DesiredCapabilities dc=	DesiredCapabilities.firefox();
	dc.setPlatform(Platform.LINUX);
	dc.setBrowserName("firefox");
	
	
	WebDriver w=new RemoteWebDriver(new URL("http://172.168.1.29:5555/wd/hub"),dc);
	w.get("http://google.com");

	Thread.sleep(4000);
	
	w.quit();
		
		
	}

}
