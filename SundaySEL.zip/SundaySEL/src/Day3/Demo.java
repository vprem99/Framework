package Day3;

import org.openqa.selenium.WebDriver;

import FM2.Excel;
import FM2.KeyConfig;

public class Demo 
{
	
	public static void main(String[] args) throws Exception 
	{
		WebDriver wd=null;
		
		Excel.ExcelConfig("/home/lab01-04/Desktop/Frame/Book1.xls","Sheet2" );
		for(int i=1;i<=Excel.ROWNUM();i++)
		{
		String A=Excel.Read(i, 0);   // Reading Keywords
		switch(A)
		{
		case "openBrowser":
		wd=	KeyConfig.openBrowser(Excel.Read(i, 3));
			break;
		case "openUrl":
			KeyConfig.openUrl(Excel.Read(i, 3));
			break;
		case "entetText":
			KeyConfig.enterText(Excel.Read(i, 1), Excel.Read(i, 2), Excel.Read(i, 3));
			break;
		case "click":
			KeyConfig.click(Excel.Read(i, 1), Excel.Read(i, 2));
			break;
		case "dropDownSelect":
			System.out.println("Hi");
			KeyConfig.dropDownSelect(Excel.Read(i, 1), Excel.Read(i, 2), Excel.Read(i, 3));
			break;	
			
		case "LoginProcess":
			new LoginFactory(wd).LoginProcess("tester99","tester99");
			
		}
	}
	}
}