package Day3;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Execute {

	public static void main(String[] args)
	{/*
		Excel.ExcelConfig("/home/lab01-04/Desktop/data.xlsx", "Sheet1");
		
		System.out.println(Excel.Read(0, 0));
		*/
		
		
		System.setProperty("webdriver.gecko.driver", "/home/lab01-04/Desktop/SeleniumJars1/geckodriver");
		WebDriver wd=new FirefoxDriver();
		LoginFactory L=new LoginFactory(wd);
		
		HomePageFactory H=new HomePageFactory(wd);
		wd.get("http://172.168.1.45/mantisbt");
		L.LoginProcess("tester99", "tester99");
		H.LogoutClick();
		
		
	}

}
