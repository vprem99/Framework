package Day3;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class LoginFactory 
{
	WebDriver w;	
	LoginFactory(WebDriver wd)
	{
		w=wd;// Intializati0on
	}
	
	By E_UN=By.name("username");
	By E_PWD=By.name("password");
	By E_LGN=By.className("button");
	
	public void LoginProcess(String UID,String PID)
	{
		w.findElement(E_UN).sendKeys(UID);
		w.findElement(E_PWD).sendKeys(PID);
		w.findElement(E_LGN).click();
	}
}