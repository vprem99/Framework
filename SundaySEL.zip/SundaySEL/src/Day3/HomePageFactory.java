package Day3;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class HomePageFactory
{

	
	WebDriver w;
	HomePageFactory(WebDriver wd)
	{
		w=wd;
	}
	
	By E_Logout=By.linkText("Logout");

	public void LogoutClick()
	{
		w.findElement(E_Logout).click();
	}
	
	
	
}
