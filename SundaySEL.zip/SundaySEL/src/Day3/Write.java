package Day3;

import java.io.FileInputStream;
import java.io.FileOutputStream;

import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

public class Write 
{
	public static void main(String[] args) throws Exception
	{
		FileInputStream IP=new FileInputStream("/home/lab01-04/Desktop/data.xls");
		HSSFWorkbook wb=new HSSFWorkbook(IP);
		HSSFSheet s=wb.getSheet("Sheet1");
		
		//s.getRow(1).getCell(1).setCellValue("DEMO");
		//s.getRow(1).createCell(2).setCellValue("DEMO");
		s.createRow(4).createCell(2).setCellValue("DEMO");

//		FileOutputStream OP=new FileOutputStream("/home/lab01-04/Desktop/data2.xls");
		wb.write(new FileOutputStream("/home/lab01-04/Desktop/data2.xls"));
		
	}

}
