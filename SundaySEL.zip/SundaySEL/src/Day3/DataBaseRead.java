package Day3;

import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class DataBaseRead 
{
	public static void main(String[] args) throws Exception
	{
		
	Properties PR=new Properties();	
	PR.load(new FileInputStream("./utils.property"));
		
	Connection c=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "tester99", "tester99");
	ResultSet R=c.createStatement().executeQuery("select * from logindetails");		
	System.setProperty("webdriver.gecko.driver", PR.getProperty("GPATH"));
	WebDriver w=new FirefoxDriver();
	
	
	while(R.next()==true)
	{
	String U=R.getString("UN");
	String P=R.getString("PWD");
	
	w.get(PR.getProperty("URL"));
	w.findElement(By.name(PR.getProperty("e_un"))).sendKeys(U);
	w.findElement(By.name(PR.getProperty("e_pwd"))).sendKeys(Keys.ESCAPE);

	w.findElement(By.name(PR.getProperty("e_pwd"))).sendKeys(P);
	w.findElement(By.className(PR.getProperty("e_login"))).click();
	w.findElement(By.linkText(PR.getProperty("e_logout"))).click();
	}	
	
	w.quit();
	}

}
