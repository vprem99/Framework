package Day1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class FIrstScript 
{

	public static void main(String[] args) 
	{
	
		//WebDriver is Interface & FirefoxDriver ,ChromeDriver & OPera Driver 
		//class which Implements WebDriver
		
		//FirefoxDriver f=new FirefoxDriver();
		//Child c=new Child();
		//Parent p=new Child()
		System.setProperty("webdriver.gecko.driver", "/home/lab01-04/Desktop/SeleniumJars1/geckodriver");
		WebDriver w=new FirefoxDriver();// It start firefox
		w.get("http://seleniumhq.org");
		
		w.findElement(By.linkText("Download")).click();
		
		String T=w.getTitle();
		System.out.println("You are on "+T+" Page");
		
		w.findElement(By.id("q")).sendKeys("QUASTECH");
		
		/*
		http://172.168.1.45/mantisbt
		tester99
		tester99
		*/
		//w.close();
		
		
		
		
	}

}
