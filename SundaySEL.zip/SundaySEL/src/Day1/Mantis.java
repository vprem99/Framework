package Day1;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

public class Mantis 
{
	public static void main(String[] args) throws Exception 
	{
		/*class      >>   		tagname.classname
		id			>>			tagname#id
		name/type/ value		tagname[N/V/t='value of that prop']
		*/
		
		System.setProperty("webdriver.gecko.driver", "/home/lab01-04/Desktop/SeleniumJars1/geckodriver");
		WebDriver w=new FirefoxDriver();// It start firefox
		
		w.get("http://172.168.1.45/mantisbt");
		w.findElement(By.cssSelector("input[type='text']")).sendKeys("tester99");
		w.findElement(By.cssSelector("input[type='password']")).sendKeys("tester99");
		w.findElement(By.cssSelector("input.button")).click();
		
		Select s=new Select(w.findElement(By.name("project_id")));
		s.selectByVisibleText("rediff");// 
		//s.selectByIndex(3);
		//s.selectByValue("3");

		s=new Select(w.findElement(By.name("project_id")));
		
		System.out.println(s.getFirstSelectedOption().getText());
		System.out.println(s.isMultiple());
		//int a[]
	
		List<WebElement> ls=s.getOptions();
		int sz=ls.size();
		System.out.println("Total Options "+sz);
		
		for(int i=0;i<sz;i++)
		{
			System.out.println(ls.get(i).getText());
		}
		
		w.findElement(By.linkText("Report Issue")).click();
		
		w.findElement(By.cssSelector("input[value='50']")).click();
		
		w.findElement(By.id("report_stay")).click();
		Thread.sleep(3000);
		w.findElement(By.name("file")).sendKeys("/home/lab01-04/Desktop/Task2.txt");
		
		
		
		
		
		
		
		
		
		
		/*w.findElement(By.cssSelector("a[href='/mantisbt/logout_page.php']")).click();
		
		w.close();
		*/
	}
}