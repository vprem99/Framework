package cpsat;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

public class Define {
	WebDriver driver;
	public Define(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	@FindBy (xpath = "//*[@id='RHS_WYSIWYG']/div/div/a")List<WebElement> l1;
	@FindBy (xpath = "/html/body/div[5]/div/div[3]/div/div/div/div/div[2]/div[4]/ul/li[*]/a")List<WebElement> l2;
	public void top() {
		for(WebElement w1 : l1) {
			System.out.println(w1.getAttribute("href"));
		}
		
	}
	public void bottom() {
		for(WebElement w1 : l2) {
			System.out.println(w1.getAttribute("href"));
		}	
	}
	public void compare() {
		for(int i = 0; i<l1.size();i++) {
			for(int j = 0; j<l2.size();j++) {
				 Assert.assertEquals(l1.get(i).getAttribute("href"),l2.get(j).getAttribute("href"));
			}	
		}
	}

}
