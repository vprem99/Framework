package cpsat;

import org.testng.annotations.Test;

import HelperFunction.Base;

import org.testng.annotations.BeforeTest;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.AfterTest;

public class Bussiness2 extends Base {
  @Test
  public void f() throws Exception {
	  TakeScreenShot(".\\b1.png");
	  //2.
	  Actions a1 = new Actions(driver);
	  a1.moveToElement(driver.findElement(By.xpath("/html/body/div[3]/div/div/div/div[2]/div[1]/ul/li[4]/a"))).perform();
	  a1.moveToElement(driver.findElement(By.xpath("/html/body/div[3]/div/div/div/div[2]/div[1]/ul/li[4]/ul/li[2]/a"))).click().perform();
	  TakeScreenShot(".\\b2.png");
	  //3.
	  WebElement w1 = driver.findElement(By.id("search"));
	  w1.sendKeys("Infosys");
	  driver.findElement(By.xpath("//*[@id=\"header\"]/div/div[2]/a")).click();
	  //4.
	  JavascriptExecutor js = (JavascriptExecutor)driver;
	  js.executeScript("arguments[0].scrollIntoView()", driver.findElement(By.xpath("//*[@id=\"videoresults\"]/div[2]/div/span")));
	  String s1 = driver.findElement(By.xpath("//*[@id=\\\"videoresults\\\"]/div[2]/div/span")).getText();
	  int i = Integer.parseInt(s1.substring(11, 14));
	  System.out.println("Total Videos are: "+i);
	  //6.
	  WebElement w2 = driver.findElement(By.xpath("//*[@id=\"Related\"]/ul[1]/li[1]/p[2]/a"));
	  System.out.println(w2.getAttribute("href"));
	  //7.
	  w2.click();
	  
	  
  }
  @BeforeTest
  public void beforeTest() {
	  launchBrowser("chrome", false);
	  //1.
	  driver.get("https://www.ndtv.com/business");
	  
  }

  @AfterTest
  public void afterTest() throws InterruptedException {
	  Quit();
  }

}
