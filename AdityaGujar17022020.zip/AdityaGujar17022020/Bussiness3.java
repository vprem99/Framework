package cpsat;

import org.testng.annotations.Test;

import HelperFunction.Base;

import org.testng.annotations.BeforeTest;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.AfterTest;

public class Bussiness3 extends Base{
  @Test
  public void f() throws Exception {
	  //2.
	  WebElement w1 = driver.findElement(By.xpath("//*[@id=\"header-data\"]/a[3]/span/span[1]"));
	  System.out.println(w1.getText());
	  WebElement w2 = driver.findElement(By.xpath("//*[@id=\"header-data\"]/a[3]/span/span[2]/span"));
	  System.out.println(w2.getText());
	  WebElement w3 = driver.findElement(By.xpath("//*[@id=\"header-data\"]/a[3]/span/span[2]/text()"));
	  System.out.println(w3.getText());
	  //4.
	  driver.findElement(By.xpath("//*[@id=\"header-data\"]/a[4]")).click();
	  //5.
	  JavascriptExecutor js = (JavascriptExecutor)driver;
	  js.executeScript("arguments[0].scrollIntoView()", driver.findElement(By.xpath("//*[@id='Alphabetical']")));
	  driver.findElement(By.xpath("//*[@id=\"Alphabetical\"]")).click();
	  //6.
	  Actions a1 = new Actions(driver);
	  a1.moveToElement(driver.findElement(By.xpath("//*[@id=\"peerlist2\"]/li[1]/a/text()[1]"))).perform();
	  TakeScreenShot(".\\alpha.png");
	  //7.
	  System.out.println("Name : "+driver.findElement(By.xpath("//*[@id=\"peerlist2\"]/li[1]/a")).getAttribute("title"));
	  //8.
	  List<WebElement> l1 =driver.findElements(By.xpath("//*[@id=\"peerlist2\"]/li[*]/a"));
	  for(WebElement ww : l1) {
		  System.out.println(ww.getAttribute("title"));
	  }
	  
  }
  @BeforeTest
  public void beforeTest() {
	  launchBrowser("chrome", false);
	  //1.
	  driver.get("https://www.ndtv.com/business");
	  
  }

  @AfterTest
  public void afterTest() throws InterruptedException {
	  Quit();
  }

}
