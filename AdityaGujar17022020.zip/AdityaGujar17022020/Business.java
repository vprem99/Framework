package cpsat;

import org.testng.annotations.Test;

import HelperFunction.Base;

import org.testng.annotations.BeforeTest;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.AfterTest;

public class Business extends Base{
  @Test
  public void f() throws Exception {
	  Actions a1 = new Actions(driver);
	  //2.
	  List<WebElement> l1 = driver.findElements(By.xpath("/html/body/div[5]/div/div[1]/div[1]/div/div[1]/div[2]/div[1]/div[2]/div[1]/div/div[*]/h1/a"));
	  for(WebElement ww : l1) {
		  System.out.println(ww.getAttribute("href"));
	  }
	  //3.
	  WebElement w1 =driver.findElement(By.xpath("/html/body/div[3]/div/div/div/div[2]/div[1]/ul/li[3]/a"));
	  System.out.println(w1.getAttribute("title"));
	  //4.
	  a1.moveToElement(driver.findElement(By.xpath("/html/body/div[3]/div/div/div/div[2]/div[1]/ul/li[3]/a"))).contextClick().click().perform();
	  System.out.println(driver.getTitle());
	  //5.
	  List<WebElement> ll = driver.findElements(By.xpath("//*[@id=\"ins_storylist\"]/ul/li[*]/div[2]/div[1]/a"));
	  for(int i =0 ; i<3; i++) {
		  for(WebElement ww:ll) {
			  System.out.println(ww.getAttribute("href"));
		  }
	  }
	  TakeScreenShot(".\\news.png");
	  //6.
	  System.out.println(driver.getTitle());
	  
  }
  @BeforeTest
  public void beforeTest() {
	  launchBrowser("chrome", false);
	  //1.
	  driver.get("https://www.ndtv.com/business");
	  
  }

  @AfterTest
  public void afterTest() throws InterruptedException {
	  Quit();
  }

}
