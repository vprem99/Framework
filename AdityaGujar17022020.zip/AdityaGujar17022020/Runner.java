package cpsat;

import org.testng.annotations.Test;

import HelperFunction.Base;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.AfterTest;

public class Runner extends Base {
  @Test
  public void f() {
	  Define d1 = new Define(driver);
	  d1.top();
	  d1.bottom();
	  d1.compare();
  }
  @BeforeTest
  public void beforeTest() {
	  launchBrowser("chrome", false);
	  driver.get("https://www.ndtv.com/business");
	  
  }

  @AfterTest
  public void afterTest() throws InterruptedException {
	  Quit();
  }
}
//there are no junit classes to create junit test suits.