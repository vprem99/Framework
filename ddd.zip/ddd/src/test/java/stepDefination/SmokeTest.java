package stepDefination;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class SmokeTest {
	WebDriver driver;

	@Given("^Open firefox and start application$")
	public void Open_firefox_and_start_application() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "/home/mpremchand99/Desktop/SeleniumJars/chromedriver");
		driver = new ChromeDriver();
		driver.get("http://facebook.com");
	}

	@When("^I enter valid \"([^\"]*)\" and valid \"([^\"]*)\"$")
	public void I_enter_valid_username_and_valid_password(String UN,String PWD) throws Throwable {
		driver.findElement(By.name("email")).sendKeys(UN);
		driver.findElement(By.name("pass")).sendKeys(PWD);
		//driver.findElement(By.id("u_0_4")).click();
	}

	@Then("^user should be login successsfully$")
	public void user_should_be_login_successsfully() throws Throwable {
		System.out.println("Hi");
	}

}
