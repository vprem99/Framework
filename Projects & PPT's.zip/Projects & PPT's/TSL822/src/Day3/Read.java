package Day3;

import java.io.FileInputStream;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Read {

	public static void main(String[] args) throws Exception {
		/*
		 * .xls .xlsx HSSF XSSF WorkBook > Sheet> Cell(Row, Col)
		 */
		FileInputStream File_In = new FileInputStream("C:\\Users\\lntinfotech\\Desktop\\data.xlsx");
		XSSFWorkbook wb = new XSSFWorkbook(File_In);
		XSSFSheet sheet = wb.getSheet("Sheet1");

		String data = sheet.getRow(2).getCell(0).toString();
		System.out.println(data);

		int rows = sheet.getLastRowNum(); // To get Number of Rows

		System.setProperty("webdriver.chrome.driver", ".\\drivers\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.get("http://127.0.0.1:8080/apex/f?p=4950:1:1783671546672727");
		System.out.println(rows);

		for (int i = 1; i <= rows; i++) {
			List<WebElement> all = driver.findElements(By.cssSelector("a.tab_link"));
			all.get(2).click(); // Selecting Sessions
			int col = sheet.getRow(i).getLastCellNum();
			for (int j = 0; j < col; j++) {
				System.out.println(sheet.getRow(i).getCell(j).toString());
				String detail = sheet.getRow(i).getCell(j).toString();
				if (j == 0) {
					driver.findElement(By.cssSelector("input#P101_USERNAME")).clear();
					driver.findElement(By.cssSelector("input#P101_USERNAME")).sendKeys(detail);
				}
				else if (j == 1) {
					driver.findElement(By.cssSelector("input[type='password']")).clear();
					driver.findElement(By.cssSelector("input[type='password']")).sendKeys(detail);
				}
			}
			driver.findElement(By.cssSelector("button[value='Login']")).click();
			if (driver.getTitle().equals("Sessions")) {
				driver.findElement(By.linkText("Logout")).click();
				System.out.println("Login Done");
			} else {
				System.out.println("Login Failed");
				driver.get("http://127.0.0.1:8080/apex/f?p=4950:1:1783671546672727");
			}
		}
	}
}