package Day3;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class LinksCounts {

	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver", ".\\drivers\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();

		TakesScreenshot screen = (TakesScreenshot) driver;

		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);

		driver.get("http://newtours.demoaut.com/");

		// List<WebElement> all_Links = driver.findElements(By.tagName("a"));
		// List<WebElement> all_Links = driver.findElements(By.xpath("//a"));
		List<WebElement> all_Links = driver.findElements(By.cssSelector("a"));

		System.out.println("Total Links are: >> " + all_Links.size());

		System.out.println("They are ");
		/*
		 * for (int i = 0; i < all_Links.size(); i++) {
		 * System.out.println(all_Links.get(i).getText());
		 * System.out.println(all_Links.get(i).getAttribute("href"));
		 * System.out.println("--------------------------------------"); }
		 */

		for (WebElement E : all_Links) {
			System.out.println(E.getText());
			System.out.println(E.getAttribute("href"));
			System.out.println("--------------------------------------");

		}

	}

}
