package Day3;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.io.FileHandler;

public class CssLocator {

	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver", ".\\drivers\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();

		TakesScreenshot screen = (TakesScreenshot) driver;

		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);

		driver.get("http://127.0.0.1:8080/apex/f?p=4950:1:1783671546672727");

		List<WebElement> all = driver.findElements(By.cssSelector("a.tab_link"));
		all.get(2).click();

		driver.findElement(By.cssSelector("input#P101_USERNAME")).sendKeys("System");
		driver.findElement(By.cssSelector("input[type='password']")).sendKeys("Newuser123");
		driver.findElement(By.cssSelector("button[value='Login']")).click();
	
		File src=screen.getScreenshotAs(OutputType.FILE);  // It will Store in Buffer Memory 
		try {
			FileHandler.copy(src, new File(".\\screenShots\\Oracle.png"));
		} catch (IOException e) {
			
		}
		
		
		
		
		
		driver.findElement(By.cssSelector("a.navbar-link")).click();

	}
}
