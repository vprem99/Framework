package Day3;

import java.io.FileInputStream;
import java.io.FileOutputStream;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class Write {

	public static void main(String[] args) throws Exception {
		FileInputStream File_In = new FileInputStream("C:\\Users\\lntinfotech\\Desktop\\data.xlsx");
		XSSFWorkbook wb = new XSSFWorkbook(File_In);
		XSSFSheet sheet = wb.getSheet("Sheet1");

		
		
		sheet.getRow(3).createCell(1).setCellValue("LTI");
		sheet.getRow(3).createCell(2).setCellValue("LTI");
		
		sheet.createRow(5).createCell(2).setCellValue("LTI");

		sheet.createRow(3).createCell(2).setCellValue("LTI");

		
		
		wb.write(new FileOutputStream("C:\\Users\\lntinfotech\\Desktop\\data.xlsx"));
		
		System.out.println(sheet.getLastRowNum());
		System.out.println(sheet.getRow(3).getLastCellNum());
		
		
		
	}

}
