package utils;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class PeoplePOM {
	WebDriver driver;

	PeoplePOM(WebDriver driver) {
		this.driver = driver;
	}

	By people = By.linkText("PEOPLE");

	By names = By.xpath("//*[@class='featured-people']/li/h3/a");
	By reviews = By.xpath("//*[@class='featured-people']/li/p/a[2]");

	public void clickPeople() {
		driver.findElement(people).click();
	}

	public void printReviewer() {
		List<WebElement> allNames = driver.findElements(names);
		for (WebElement N : allNames) {
			System.out.println(N.getText());
		}

	}

	public void printFirstNumofReviews() {
		System.out.println(driver.findElement(reviews).getText());
	}

}
