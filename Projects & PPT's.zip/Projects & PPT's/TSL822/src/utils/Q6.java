package utils;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.SessionNotCreatedException;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;


public class Q6 {
	WebDriver driver;

	@Test
	public void f() throws Exception{
		driver.get("https://www.shoppersstop.com/");

		new Actions(driver).moveToElement(driver.findElement(By.linkText("GIFTS"))).perform();
		new Actions(driver).moveToElement(driver.findElement(By.linkText("Gifts For Him"))).perform();

		String txt = driver
		.findElement(By
	    .xpath("/html/body/main/nav/div[2]/div/ul/li[9]/div/div/ul/li[2]/div/ul/li[1]/div/ul/li/div/ul"))
		.getText();
		System.out.println(txt);

		driver.findElement(By.linkText("All Stores")).click();
		Thread.sleep(3000);

		Select s=new Select(driver.findElement(By.id("city-name")));
		Thread.sleep(3000);

		s.selectByVisibleText("Mumbai");

		List<WebElement> l = new Select(driver.findElement(By.id("selectedPOS"))).getOptions();

		for (WebElement LL : l) {
			System.out.println(LL.getText());
		}
		SoftAssert SA=new SoftAssert();
		SA.assertTrue(checkCity("Jaipur"),"JaiPur not Present");
		SA.assertTrue(checkCity("Ranchi"),"Ranchi not Preset");
		SA.assertTrue(checkCity("Chennai"),"CHennai not Present");
		SA.assertAll();

	}
	
	public boolean checkCity(String City)
	{
		boolean flag=false;
		List<WebElement> allCity=new Select(driver.findElement(By.id("city-name"))).getOptions();

		for(WebElement D:allCity)
		{
			if(D.getText().contains(City))
			{
				flag=true;
				break;
			}
		
		}
		return flag;
}

	@BeforeTest
	public void beforeTest() {
		System.setProperty("webdriver.chrome.driver", ".\\drivers\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.manage().window().maximize();
	}

	@AfterTest
	public void afterTest() {
		//driver.quit();
	}

}
