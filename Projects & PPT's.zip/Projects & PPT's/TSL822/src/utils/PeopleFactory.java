package utils;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class PeopleFactory {
	//WebDriver driver;

	PeopleFactory(WebDriver driver) {
		PageFactory.initElements(driver,this);
	}
	@FindBy(linkText="PEOPLE") WebElement people;
	@FindBy(xpath="//*[@class='featured-people']/li/h3/a") List<WebElement> names;
	@FindBy(xpath="//*[@class='featured-people']/li/p/a[2]") WebElement reviews;
	
	
	public void clickPeople() {
		people.click();
	}

	public void printReviewer() {

		for (WebElement N : names) {
			System.out.println(N.getText());
		}

	}
	
	public void printFirstNumofReviews()
	{
		System.out.println(reviews.getText());
	}
	
	
	
	
	


}
