package utils;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;


public class Q5 {
	WebDriver driver;

	@Test
	public void f() {
		driver.get("https://letterboxd.com/");
		
		Assert.assertTrue(driver.getTitle().contains("Letterboxd"),"Title mismatched");
	//	PeoplePOM People=new PeoplePOM(driver);
		
		PeopleFactory People=new PeopleFactory(driver);
		People.clickPeople();
		People.printReviewer();
		People.printFirstNumofReviews();
		
		Select s=new Select(driver.findElement(By.linkText("")));
	
		
		
		
	}

	@BeforeTest
	public void beforeTest() {
		System.setProperty("webdriver.chrome.driver", ".\\drivers\\chromedriver.exe");
		driver = new ChromeDriver();
	}

	@AfterTest
	public void afterTest() {
		//driver.quit();
	}

}
