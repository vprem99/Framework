package Day1;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class MultiDropDown {

	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver",
				"D:\\Share Folder\\1SelJars\\chromedriver_win32\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();

		driver.get("http://192.168.12.223:9090/dropdown.html");

		WebElement cars = driver.findElement(By.name("cars"));

		Select s = new Select(cars);

		System.out.println("IS Multi Select " + s.isMultiple());

		s.selectByVisibleText("ABC");
		s.selectByVisibleText("Audi");
		s.deselectByVisibleText("Audi");
		// Works only if dropdown is multi-select
		s.selectByVisibleText("Audi");
		Thread.sleep(6000);
		s.deselectAll();

		List<WebElement> all_Option = s.getOptions();

		System.out.println("Total options are " + all_Option.size());

		System.out.println("They are ");

		for (WebElement E : all_Option) {
			System.out.println(E.getText());
		}
	}
}