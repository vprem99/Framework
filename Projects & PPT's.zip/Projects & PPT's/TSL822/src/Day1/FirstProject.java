package Day1;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class FirstProject {

	public static void main(String[] args) {

		/*
		 * WebDriver is interface FirefoxDriver, ChromeDriver, OperaDriver are
		 * Classes which implements WebDriver
		 */

		System.setProperty("webdriver.chrome.driver",
				"D:\\Share Folder\\1SelJars\\chromedriver_win32\\chromedriver.exe");
		;
		WebDriver driver = new ChromeDriver();
		// Parent P=new Child
		/*
		 * Only Common methods will be visible and Child specific methods will
		 * be hidden Which will give 100 % surety during compatibility testing
		 * about methods
		 */

		// ChromeDriver driver=new ChromeDriver();
		driver.get("http://selenium.dev");
		WebElement download = driver.findElement(By.linkText("Downloads"));
		
		download.click();// For Clicking
		String title = driver.getTitle(); // Getting current Page Title
		System.out.println("You are on " + title + " Page");
		driver.findElement(By.name("search")).sendKeys("selenium");
		driver.findElement(By.name("search")).sendKeys(Keys.ENTER);
		driver.quit();// Closing Browser

	}
}
