package Day1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class dropDown {

	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver",
				"D:\\Share Folder\\1SelJars\\chromedriver_win32\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();

		driver.get("https://www.facebook.com/");

		// driver.findElement(By.name("birthday_month")).sendKeys("May");

		Select month = new Select(driver.findElement(By.name("birthday_month")));
		// month.selectByVisibleText("Nov");
		// month.selectByIndex(9);
		month.selectByValue("10");
		driver.findElement(By.id("u_0_a")).click();
		
	}
}