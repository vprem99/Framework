package Day1;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class OrangeHRM {

	public static void main(String[] args) throws Exception {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\lntinfotech\\Downloads\\chromedriver_win32 (2)\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();

		WebDriverWait wt = new WebDriverWait(driver, 15);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		// Global Wait which is Applicable for All below Objects
		// if they are visible
		driver.get("https://opensource-demo.orangehrmlive.com/");
		driver.findElement(By.name("txtUsername")).sendKeys("admin");
		driver.findElement(By.name("txtPassword")).sendKeys("admin123");
		driver.findElement(By.name("Submit")).click();
		//Thread.sleep(3000);
		// wt.until(ExpectedConditions.elementToBeClickable(By.id("welcome")));
/*		WebElement E=driver.findElement(By.linkText("Welcome Admin"));
		E.click();
*/		
		
		new Actions(driver).click(driver.findElement(By.linkText("Welcome Admin"))).perform();
		// Thread.sleep(3000);
		// Synchronization Problem
		// Matching Speed between two things i.e Orange HRM & Selenium

		  wt.until(ExpectedConditions
		  .visibilityOfElementLocated(By.linkText("Logout")));
	 
		driver.findElement(By.linkText("Logout")).click();
	}
}