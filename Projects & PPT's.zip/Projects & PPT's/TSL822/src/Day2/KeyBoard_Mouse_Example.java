package Day2;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class KeyBoard_Mouse_Example {

	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver",
				".\\browser\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Actions actions = new Actions(driver);

		// if they are visible
		driver.get("https://opensource-demo.orangehrmlive.com/");
		driver.findElement(By.name("txtUsername")).sendKeys("admin");
		driver.findElement(By.name("txtPassword")).sendKeys("admin123");
		driver.findElement(By.name("Submit")).click();
		
		
		actions.moveToElement(driver.findElement(By.linkText("PIM"))).perform();
		
		actions.moveToElement(driver.findElement(By.linkText("Configuration"))).perform();


		
		actions.click(driver.findElement(By.linkText("Optional Fields"))).perform();

	}

}
