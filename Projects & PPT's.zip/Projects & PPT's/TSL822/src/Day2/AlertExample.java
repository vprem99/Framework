package Day2;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class AlertExample {

	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver", ".\\drivers\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Actions actions = new Actions(driver);

		driver.get("https://www.magneticautomation.in/2019/01/alert-example.html");

		driver.findElement(By.xpath("//*[@id='post-body-5405753133268992336']/div/button[3]")).click();

		
		Alert A=driver.switchTo().alert();
		String msg = A.getText();

		System.out.println(msg);

		A.sendKeys("LTI"); // Typing in Prompt
		//A.accept(); // Pressing on OK
		A.dismiss(); // Pressing on Cancel

	}

}
