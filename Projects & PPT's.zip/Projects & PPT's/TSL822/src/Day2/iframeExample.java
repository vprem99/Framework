package Day2;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

public class iframeExample {

	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver", ".\\drivers\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Actions actions = new Actions(driver);

		driver.get("http://192.168.12.223:9090/iframe.html");

		driver.switchTo().frame("blaze");

		Select s = new Select(driver.findElement(By.name("fromPort")));

		s.selectByVisibleText("Boston");

		driver.switchTo().defaultContent();
		driver.switchTo().frame("bing");

		driver.findElement(By.name("q")).sendKeys("ABC");

		driver.switchTo().defaultContent();
		driver.switchTo().frame(2);

		driver.findElement(By.id("dropdownButton")).click();

	}

}
