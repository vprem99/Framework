package Day2;

import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class UGC1 {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", ".\\drivers\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Actions actions = new Actions(driver);
		// if they are visible
		driver.get("https://www.ugc.ac.in/");

		String parent_id = driver.getWindowHandle();

		WebElement RTI = driver.findElement(By.linkText("RTI"));
		
		

		actions.keyDown(Keys.CONTROL).click(RTI).perform();

		Set<String> all = driver.getWindowHandles();

		for (String T : all) {

			if (!(T.equals(parent_id))) {

				driver.switchTo().window(T);
				System.out.println("Title of Child Tab is " + driver.getTitle());
				driver.close();
			}
		}

		Thread.sleep(5000);
		driver.quit();
	}
}