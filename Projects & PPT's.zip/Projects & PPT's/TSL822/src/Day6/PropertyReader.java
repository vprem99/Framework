package Day6;

import java.io.FileInputStream;
import java.util.Properties;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.testng.annotations.Test;
import utils.Base;

public class PropertyReader extends Base {

	@Test
	public void f() throws Exception {
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.get(prop.getProperty("url"));
		Thread.sleep(4000);

		System.out.println(prop.getProperty("search"));
		driver.findElement(getElement(prop.getProperty("search"))).sendKeys("LTI");
		driver.findElement(getElement(prop.getProperty("searchButton"))).click();

	}

	public By getElement(String Locator) {
		String LocatorType = Locator.split(":=")[0];
		String LocatorValue = Locator.split(":=")[1];

		if (LocatorType.equalsIgnoreCase("id")) {
			return By.id(LocatorValue);
		} else if (LocatorType.equalsIgnoreCase("name")) {
			return By.name(LocatorValue);
		} else if (LocatorType.equalsIgnoreCase("xpath")) {
			return By.xpath(LocatorValue);
		} else
			return null;
	}

	
	
	
}
