package Day7POM;

import org.testng.annotations.Test;

import fm.KeyWords;
import utils.Base;

public class ExecuteKeyWords extends Base{
  @Test
  public void f() throws Exception{
	  
	  KeyWords Key=new KeyWords(driver);
	  Key.getUrl("http://bing.com");
	  Key.type("name:=q", "Sara Ali Khan");
	  Key.click("xpath:=//body/div[contains(@class,'hp_body')]/div[@class='hp_cont']/div[@class='sbox']/form[@id='sb_form']/label[@class='search icon tooltip']/*[1]");
	  
	  Thread.sleep(4000);
	  
  }
}
