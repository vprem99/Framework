package Day7POM;

import java.io.File;

import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.io.FileHandler;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class HeadLess {
	WebDriver driver;

	@Test
	public void f() {
		driver.get("http://google.com");
		driver.findElement(By.name("q")).sendKeys("LTI");
		File src = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		try {
			FileHandler.copy(src, new File(".\\screenShots\\A.png"));
		} catch (Exception E) {
			System.out.println("Error while Screenshots");
		}
	}

	@BeforeTest
	public void beforeTest() {
		System.setProperty("webdriver.chrome.driver", ".\\drivers\\chromedriver.exe");
		ChromeOptions OP = new ChromeOptions();
		OP.addArguments("--headless");
		driver = new ChromeDriver(OP);
	}

	@AfterTest
	public void afterTest() {
	driver.quit();
	}

}
