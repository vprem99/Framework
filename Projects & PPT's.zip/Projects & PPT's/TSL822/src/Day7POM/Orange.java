package Day7POM;

import org.openqa.selenium.NoSuchElementException;
import org.testng.Assert;
import org.testng.annotations.Test;

import utils.Base;

public class Orange extends Base {
	@Test
	public void OrangeLogin() {
		driver.get(prop.getProperty("url2"));
		LoginPOM LP = new LoginPOM(driver);
		LP.LoginProcess("admin", "admin12322");
//		Assert.assertEquals(driver.getCurrentUrl(), "https://opensource-demo.orangehrmlive.com/index.php/dashboard");
		WelcomePage WP = new WelcomePage(driver);

		try {
			WP.clickLogout();
		} catch (NoSuchElementException N) {
			throw new AssertionError("Login Failed");
		}
	}
}
