package Day7POM;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.testng.annotations.Test;

import utils.Base;

public class Scrolling extends Base {

	@Test
	public void f() throws Exception {
		JavascriptExecutor JS = (JavascriptExecutor) driver;
		driver.get(prop.getProperty("url3"));

		// To Scroll to Specific WebElement
		JS.executeScript("arguments[0].scrollIntoView();", driver.findElement(By.linkText("diemol")));

		Thread.sleep(5000);

		JS.executeScript("window.scrollBy(0,-150)");
		Thread.sleep(5000);
		// To scroll with X & Y axis

		JS.executeScript("window.scrollBy(0,document.body.scrollHeight)");
		// To scroll bottom of Page
		Thread.sleep(5000);

		JS.executeScript("window.scrollBy(0,-document.body.scrollHeight)");

		Thread.sleep(5000);

		JS.executeScript("arguments[0].click();", driver.findElement(By.linkText("diemol")));

		Thread.sleep(5000);

	}
}
