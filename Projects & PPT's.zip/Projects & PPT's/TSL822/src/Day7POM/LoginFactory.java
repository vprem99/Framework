package Day7POM;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LoginFactory {

	LoginFactory(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}

	//@FindBy(name = "txtUsername")	WebElement userName;

	
	WebElement txtUsername;
	WebElement txtPassword;
	//@FindBy(name = "txtPassword")	WebElement passWord;

	//@FindBy(name = "Submit") 	WebElement Submit;
	WebElement Submit;
	@FindBy(linkText = "Forgot your password?") 	WebElement forget;

	public void LoginProcess(String UN, String PWD) {
		txtUsername.sendKeys(UN);
		txtPassword.sendKeys(PWD);
		Submit.click();
	}

	public void clickForget() {
		forget.click();
	}

}
