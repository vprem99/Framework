package Day7POM;

import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.Cookie;
import org.openqa.selenium.NoSuchElementException;
import org.testng.annotations.Test;

import utils.Base;

public class CookieTest extends Base {
	@Test
	public void CookiesPrint() {
		driver.get(prop.getProperty("url2"));
		LoginPOM LP = new LoginPOM(driver);
		LP.LoginProcess("admin", "admin123");

		Set<Cookie> All_CK = driver.manage().getCookies();

		for (Cookie C : All_CK) {
			System.out.println("==========================================");
			System.out.println("Cookie Name is " + C.getName());
			System.out.println("Cookie Domain is " + C.getDomain());
			System.out.println("Cookie Value is " + C.getValue());
			System.out.println("Cookie Path is " + C.getPath());
			System.out.println("Cookie Expiry is " + C.getExpiry());
		}
		driver.manage().deleteAllCookies();
		driver.navigate().refresh();
		try {
			driver.findElement(By.name("txtUsername"));
		} catch (NoSuchElementException N) {
			throw new AssertionError("Cookie Test Failed");
		}
	}
}