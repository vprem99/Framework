package Day7POM;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class LoginPOM {
	private WebDriver driver;

	public LoginPOM(WebDriver driver) {
		this.driver = driver;
	}

	private By userName = By.name("txtUsername");
	private By passWord = By.name("txtPassword");
	private By submit = By.name("Submit");
	private By forget = By.linkText("Forgot your password?");

	public void LoginProcess(String UN, String PWD) {
		driver.findElement(userName).sendKeys(UN);
		driver.findElement(passWord).sendKeys(PWD);
		driver.findElement(submit).click();
	}

	public void clickForget() {
		driver.findElement(forget).click();
	}

}