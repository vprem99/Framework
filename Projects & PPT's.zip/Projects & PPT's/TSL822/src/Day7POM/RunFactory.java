package Day7POM;

import org.testng.annotations.Test;

import utils.Base;

public class RunFactory extends Base {
	@Test
	public void f() {
		driver.get(prop.getProperty("url2"));
		LoginFactory LF = new LoginFactory(driver);
		LF.LoginProcess("admin", "admin123");
	}
}
