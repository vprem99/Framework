package Day5;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class FirstNG {
	WebDriver driver;

	@Test(priority=1,description="Title test for Google")
	public void TitleTest() {
		driver.get("https://www.google.com/");
		String title = driver.getTitle();
		Assert.assertEquals(title, "Google123","Title Mismatch");
	}

	@Test(priority=2,dependsOnMethods="TitleTest",description="Search Test for Google")
	public void SearchTest() {
		WebElement E=driver.findElement(By.name("q"));
		Assert.assertEquals(E.isDisplayed(),true);
		Assert.assertEquals(E.isEnabled(),true);
		Assert.assertEquals(E.getAttribute("maxlength"),"2048");
	}

	@BeforeTest
	public void beforeTest() {
		System.setProperty("webdriver.chrome.driver", ".\\drivers\\chromedriver.exe");
		driver = new ChromeDriver();
	}

	@AfterTest
	public void afterTest() {
		driver.quit();
	}

}
