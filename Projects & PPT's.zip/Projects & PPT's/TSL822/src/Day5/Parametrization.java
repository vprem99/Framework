package Day5;

import java.io.File;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.io.FileHandler;
import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import fm.ExcelReader;

public class Parametrization {
	WebDriver driver;
	static int i = 1;

	@Test(dataProvider = "dp")
	public void LoginProcess(String n, String s) {
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.get("http://127.0.0.1:8080/apex/f?p=4950:1:1783671546672727");
		List<WebElement> all = driver.findElements(By.cssSelector("a.tab_link"));
		all.get(2).click(); // Selecting Sessions
		driver.findElement(By.cssSelector("input#P101_USERNAME")).clear();
		driver.findElement(By.cssSelector("input#P101_USERNAME")).sendKeys(n);
		driver.findElement(By.cssSelector("input[type='password']")).clear();
		driver.findElement(By.cssSelector("input[type='password']")).sendKeys(s);
		driver.findElement(By.cssSelector("button[value='Login']")).click();
		Assert.assertEquals(driver.getTitle(), "Sessions", "Title Mismatch & Login Falied");
		driver.findElement(By.linkText("Logout")).click();
	}

	@AfterMethod
	public void afterMethod(ITestResult result) {
		System.out.println("In After Method");

		if (result.getStatus() == ITestResult.FAILURE) {

			File src = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
			try {
				FileHandler.copy(src, new File(".\\screenShots\\" + result.getName() + i + ".png"));
			} catch (Exception E) {
				System.out.println("Error while Screenshots");
			}
			i++;
		}
	}

	@DataProvider
	public Object[][] dp() {

		/*
		 * Object data[][] = new Object[4][2]; data[0][0] = "Sys"; data[0][1] =
		 * "Newuser123"; data[1][0] = "System"; data[1][1] = "Newuser123";
		 * data[2][0] = "hr"; data[2][1] = "dddddd"; data[3][0] = "demo";
		 * data[3][1] = "demo";
		 */

		ExcelReader ex = new ExcelReader("D:\\Share Folder\\AT\\data2.xlsx");
		Object data[][] = ex.getAllData("Sheet1", 4, 2);
		return data;
	}

	@BeforeTest
	@Parameters("browser")
	public void beforeTest(String browser) {
		if (browser.equalsIgnoreCase("chrome")) {
			System.setProperty("webdriver.chrome.driver", ".\\drivers\\chromedriver.exe");
			driver = new ChromeDriver();
		} else if (browser.equalsIgnoreCase("firefox")) {
			System.setProperty("webdriver.gecko.driver", ".\\drivers\\geckodriver.exe");
			driver = new FirefoxDriver();
		}
	}

	@AfterTest
	public void afterTest() {
		driver.quit();
	}

}
