package Day5;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.AfterTest;

public class Sample {
	@Test
	public void test1() {
		System.out.println("In  Test 1");
	}

	@Test
	public void test2() {
		System.out.println("In  Test 2");
	}
	@BeforeMethod
	public void beforeMethod() {
		System.out.println("In Before Method");
	}

	@AfterMethod
	public void afterMethod() {
		System.out.println("In After Method");
	}

	@BeforeTest
	public void beforeTest() {
		System.out.println("In Before Test");
	}

	@AfterTest
	public void afterTest() {
		System.out.println("In After Test");

	}

}
