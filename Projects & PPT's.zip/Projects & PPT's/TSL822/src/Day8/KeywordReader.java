package Day8;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import fm.ExcelReader;
import fm.KeyWords;
import utils.Base;

public class KeywordReader extends Base {
	@Test(dataProvider = "dp")
	public void f(String Actions, String Locator, String Data) {
		KeyWords Key = new KeyWords(driver);
		if (Actions.equalsIgnoreCase("getUrl"))
			Key.getUrl(Data);
		else if (Actions.equalsIgnoreCase("click"))
			Key.click(Locator);
		else if (Actions.equalsIgnoreCase("type"))
			Key.type(Locator, Data);
		else if (Actions.equalsIgnoreCase("getSnap"))
			Key.getSnap(Locator, Data);
		else
			System.out.println("Invalid Key");
	}

	@DataProvider
	public Object[][] dp() {
		ExcelReader ex = new ExcelReader("D:\\Share Folder\\AT\\Suite.xlsx");
		Object ExcelKeys[][] = ex.getAllData("Sheet1", 6, 3);
		return ExcelKeys;
	}
}
