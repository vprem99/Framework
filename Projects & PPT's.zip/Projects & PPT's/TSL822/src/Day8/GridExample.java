package Day8;

import java.net.URL;

import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import Day7POM.LoginPOM;

public class GridExample {
	WebDriver driver;

	@BeforeTest
	@Parameters({ "node", "browser" })
	public void beforeTest(String node, String browser) throws Exception {
		DesiredCapabilities dc=null;
		if (browser.equalsIgnoreCase("chrome")) {
			dc = DesiredCapabilities.chrome();
			dc.setBrowserName("chrome");
		} else if (browser.equalsIgnoreCase("firefox")) {
			dc = DesiredCapabilities.firefox();
			dc.setBrowserName("firefox");
		}
		dc.setPlatform(Platform.WINDOWS);
		driver = new RemoteWebDriver(new URL(node), dc);
	}

	@Test
	public void f() throws Exception {
		driver.get("https://opensource-demo.orangehrmlive.com/");
		LoginPOM LP = new LoginPOM(driver);
		LP.LoginProcess("admin", "admin123");
		driver.quit();
	}

	@AfterTest
	public void afterTest() {
		driver.quit();
	}

}
