package Day6Junit;

import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class LinksImages {
	static WebDriver driver;

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		System.setProperty("webdriver.chrome.driver", ".\\drivers\\chromedriver.exe");
		driver = new ChromeDriver();
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		driver.quit();
	}

	@Test
	public void test() {
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.get("http://bing.com");
		List<WebElement> LinksImg = driver.findElements(By.tagName("a"));
		LinksImg.addAll(driver.findElements(By.xpath("//img")));

		for (WebElement E : LinksImg) {
			String href = E.getAttribute("href");
			try {
				URL url = new URL(href); // Converting String into URL type
				URLConnection UC = url.openConnection(); // OPens a Channel for
															// Connection
				HttpURLConnection HUC = (HttpURLConnection) UC;
				HUC.connect();

				int code = HUC.getResponseCode();

				if (code == 200) {
					System.out.println(href + " is working");

				} else {
					System.out.println(href + " is not working");
				}

			} catch (Exception e) {

				System.out.println(e.getMessage());

			}

		}

	}
}
