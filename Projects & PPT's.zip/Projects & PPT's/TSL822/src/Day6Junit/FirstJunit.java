package Day6Junit;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.util.concurrent.TimeUnit;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class FirstJunit {
	static WebDriver driver;

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		System.setProperty("webdriver.chrome.driver", ".\\drivers\\chromedriver.exe");
		driver = new ChromeDriver();

	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		driver.quit();
	}

	@Test
	public void test() {
		// driver.navigate().to("http://bing.com");
		// to() method does not wait for page to get fully loaded
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);

		driver.get("http://bing.com");
		assertEquals("Title mismatch ", "Bing", driver.getTitle());
		WebElement E = driver.findElement(By.id("sbi_b"));
		assertTrue(E.isDisplayed());
		assertTrue(E.isEnabled());
		System.out.println("Source is ");
		System.out.println(E.getAttribute("src"));
	}
}