package fm;

public class Execute {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ExcelReader ex=new ExcelReader("C:\\Users\\lntinfotech\\Desktop\\data2.xlsx");
		
		/*for(int i=1;i<=ex.getRowNum("Sheet1");i++)
		{
			System.out.println(i);
		System.out.println(ex.getCellData("Sheet1", i, 0));
		}	*/

		String d[][]=ex.getAllData("sheet1", 3, 2);
		
		for(int i=0;i<d.length;i++)
		{
			System.out.println(d[i][0]);
			System.out.println(d[i][1]);
		}
	
	
	}

}
