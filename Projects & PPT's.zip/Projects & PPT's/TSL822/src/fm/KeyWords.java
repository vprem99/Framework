package fm;

import java.io.File;
import java.io.IOException;
import java.util.Date;

import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.io.FileHandler;

public class KeyWords {
	WebDriver driver;

	public KeyWords(WebDriver driver) {
		this.driver = driver;
	}

	public void getUrl(String url) {
		driver.get(url);
	}

	public void type(String Locator, String data) {
		driver.findElement(getElement(Locator)).sendKeys(data);
	}

	public void click(String Locator) {
		driver.findElement(getElement(Locator)).click();
	}

	public void getSnap(String Location, String name) {
		File src = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		String D = new Date().toString().replaceAll(" ", "_").replaceAll(":", "_");

		try {
			FileHandler.copy(src, 
					new File(Location + "\\" + name + D + ".png"));
		} catch (IOException e) {
			System.out.println("Error with Taking ScreenShot");
		}
	}

	public By getElement(String Locator) {
		String LocatorType = Locator.split(":=")[0];
		String LocatorValue = Locator.split(":=")[1];

		if (LocatorType.equalsIgnoreCase("id")) {
			return By.id(LocatorValue);
		} else if (LocatorType.equalsIgnoreCase("name")) {
			return By.name(LocatorValue);
		} else if (LocatorType.equalsIgnoreCase("xpath")) {
			return By.xpath(LocatorValue);
		} if (LocatorType.equalsIgnoreCase("link")) {
			return By.linkText(LocatorValue);
		}
		
		
		else
			return null;
	}

	public static void main(String[] args) {
		Date d = new Date();
		String D = d.toString().replaceAll(" ", "_").replaceAll(":", "_");
		System.out.println(D);
	}

}
