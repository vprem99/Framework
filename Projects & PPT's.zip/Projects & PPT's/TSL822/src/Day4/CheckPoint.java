package Day4;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class CheckPoint {

	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver",
				"D:\\Share Folder\\1SelJars\\chromedriver_win32\\chromedriver.exe");
		WebDriver driver = new HTMLUnitDriver(true);  //Headless Execution of Script By Seleniu

		driver.get("https://www.facebook.com/");

		WebElement gender=driver.findElement(By.name("sex"));
		boolean a=gender.isDisplayed();
		boolean b=gender.isEnabled();
		boolean c=gender.isSelected();
		String type=gender.getAttribute("type");
		
		if(a==true && b==true && c==false && type.equals("radio"))
			System.out.println("Test for Gender is Pass");
		else
			System.out.println("Test for Gender is Fail");
		
		
		
		
		
		
	}
}
