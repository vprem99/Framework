package Day4;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class DB {

	public static void main(String[] args) throws Exception {
		Class.forName("oracle.jdbc.driver.OracleDriver");
		Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "hr", "hr");
		ResultSet R = con.createStatement().executeQuery("Select * from login");
		System.setProperty("webdriver.chrome.driver", ".\\drivers\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.get("http://127.0.0.1:8080/apex/f?p=4950:1:1783671546672727");
		while (R.next()) {
			String UN = R.getString("UN");
			String PWD = R.getString("PWD");
			List<WebElement> all = driver.findElements(By.cssSelector("a.tab_link"));
			all.get(2).click(); // Selecting Sessions
			driver.findElement(By.cssSelector("input#P101_USERNAME")).clear();
			driver.findElement(By.cssSelector("input#P101_USERNAME")).sendKeys(UN);
			driver.findElement(By.cssSelector("input[type='password']")).clear();
			driver.findElement(By.cssSelector("input[type='password']")).sendKeys(PWD);
			driver.findElement(By.cssSelector("button[value='Login']")).click();
			
			PreparedStatement stmt=con.prepareStatement("update login set status= ? where UN= ?");  
			stmt.setString(2, UN);
			if (driver.getTitle().equals("Sessions")) {
				driver.findElement(By.linkText("Logout")).click();
				System.out.println("Login Done");
				stmt.setString(1, "PASS");
			} else {
				System.out.println("Login Failed");
				stmt.setString(1, "FAIL");
				driver.get("http://127.0.0.1:8080/apex/f?p=4950:1:1783671546672727");
			}
			stmt.executeUpdate();  	
		}
	}
}