package com.expedia.hotel;

import java.util.Properties;
import java.util.Set;

import org.apache.poi.ss.usermodel.Workbook;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.ExtentTest;
import com.expedia.util.BasePOM;



public class HotelPom extends BasePOM {

	 	public HotelPom(WebDriver driver) {
	 		super(driver);
}
	 	
	 	public void hotelSearch(String url,String Destination,String CheckIn,String CheckOut, ExtentTest log1) throws InterruptedException{
//	 		driver.switchTo().window(driver.getWindowHandles().toArray()[0].toString());
			log1.info("Hotel Booking Test Strated");

	 		if(driver.getWindowHandles().size()>1){
				driver.switchTo().window(driver.getWindowHandles().toArray()[1].toString()).close();

				driver.switchTo().window(driver.getWindowHandles().toArray()[0].toString());
			}
	 		driver.get(url);
	 		driver.findElement(getElement("hotelClick")).click();
	 		driver.findElement(getElement("hotelGoingTo")).clear();
	 		driver.findElement(getElement("hotelGoingTo")).sendKeys(Destination);	 		
	 		driver.findElement(getElement("hotelCheckIn")).sendKeys(Keys.BACK_SPACE,Keys.BACK_SPACE,Keys.BACK_SPACE,
	 				Keys.BACK_SPACE,Keys.BACK_SPACE,Keys.BACK_SPACE,Keys.BACK_SPACE,Keys.BACK_SPACE,Keys.BACK_SPACE,
	 				Keys.BACK_SPACE,CheckIn);
	 		driver.findElement(getElement("hotelCheckOut")).sendKeys(Keys.BACK_SPACE,Keys.BACK_SPACE,Keys.BACK_SPACE,
	 				Keys.BACK_SPACE,Keys.BACK_SPACE,Keys.BACK_SPACE,Keys.BACK_SPACE,Keys.BACK_SPACE,Keys.BACK_SPACE,
	 				Keys.BACK_SPACE,CheckOut,Keys.ENTER);
//	 		Thread.sleep(1000);
	 	}
	 	
	 	public void hotelClick( ExtentTest log1) throws Exception {
	 		Thread.sleep(2000);
	 		driver.findElement(getElement("hotelName")).click();    
	 	}
	 	
	 	public void hotelExplore( ExtentTest log1) throws Exception{
	 		
	 		String pw= driver.getWindowHandle();
	 		Set<String> all=driver.getWindowHandles();
	 		for(String e: all) {
	 			if(!(equals(pw))){
	 				driver.switchTo().window(e);
	 		}
	 		}
	 		try{
	 		 driver.findElement(getElement("hotelBook")).click();
	 					
			driver.findElement(getElement("pay")).click();
	 					}
	 					catch(Exception e){
	 						System.out.println("pay is not clicked");
	 						
//	 						driver.close();
//	 						driver.switchTo().window(driver.getWindowHandles().toArray()[0].toString());
	 					}
	 	}
	 	
	 	public void contactDetails(String ContName,String MobileNum, ExtentTest log1) throws InterruptedException{
//	 		Thread.sleep(3000);
	 		try{
	 		driver.findElement(getElement("contactName")).sendKeys(ContName);
	 		driver.findElement(getElement("contactNumber")).sendKeys(MobileNum);
	 		}
	 		catch(Exception e){
					System.out.println("pay is not clicked");
//					driver.close();
//					driver.switchTo().window(driver.getWindowHandles().toArray()[0].toString());
				}
	 	}
	 	
	 	public void cardDetails(String CardNum,String Exp_M,String Exp_y,String cvv,ExtentTest log1) throws Exception{
	 		try{
	 		driver.findElement(getElement("debitCreditCard")).sendKeys(CardNum);
	 		
	 		WebElement month=driver.findElement(getElement("card_m"));
	 		Select Month=new Select(month);
	 		Month.selectByIndex(Integer.parseInt(Exp_M));
	 		
	 		WebElement year=driver.findElement(getElement("card_y"));
	 		Select Year=new Select(year);
//	 		Thread.sleep(3000);
	 		Year.selectByVisibleText(Exp_y);
	 		driver.findElement(getElement("cvv_h")).sendKeys(cvv);
	 		}
	 		catch(Exception e){
				
 		log1.pass("Successfully Booked a Hotel");
	 		}
	 			
	 		}
	 	
	 	}