
package com.expedia.signIn;

import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.expedia.util.Base;
import com.expedia.util.BasePOM;

import net.bytebuddy.agent.builder.AgentBuilder.Identified.Extendable;

public class SignInPOM extends BasePOM {

	public SignInPOM(WebDriver driver) {
		super(driver);
	}

	public void normalSignIn(String Email, String Password, ExtentTest log1) throws Exception {
		
		log1.info("Account Signin");

		driver.findElement(getElement("accountId")).click();
		driver.findElement(getElement("accountSigninId")).click();
		Thread.sleep(3000);

		driver.findElement(getElement("normalSigninEmailId")).clear();
		driver.findElement(getElement("normalSigninPassId")).clear();
		driver.findElement(getElement("normalSigninEmailId")).sendKeys(Email);
		driver.findElement(getElement("normalSigninPassId")).sendKeys(Password);
		driver.findElement(getElement("normalSigninCheckBoxId")).click();
		driver.findElement(getElement("normalClickSigninId")).click();
		Thread.sleep(60000);
//		System.out.println(driver.getTitle());
//		String titleSignin = "Expedia Travel: Vacations, Cheap Flights, Airline Tickets & Airfares";
		try {
			Thread.sleep(3000);
			driver.findElement(getElement("normalSigninAccClickId")).click();
			log1.info("Signed in successfully through normalsignin");
			log1.pass("Signed in successfully through normalsignin");
			driver.findElement(getElement("SignOutId")).click();
			Thread.sleep(3000);
			log1.info("Signed out successfully through normalsignin");
		} 
		catch (Exception e) {
			System.out.println("after assert");
			log1.fail("Signed out failed through normalsignin");
			throw new AssertionError("Login Fail");
		}


	}

	public void googleSignIn(String GoogleEmail, String GooglePassword,ExtentTest log1) throws Exception {
		log1.info("Google Signin");
		driver.findElement(getElement("accountId")).click();
		driver.findElement(getElement("accountSigninId")).click();
		Thread.sleep(3000);
		driver.findElement(getElement("googleSignInId")).click();
		String pa = driver.getWindowHandle();
		Set<String> all = driver.getWindowHandles();
		for (String e : all) {
			if (!(equals(pa))) {
				driver.switchTo().window(e);
			}
		}
		try {
			Thread.sleep(2000);
			driver.findElement(getElement("googleSignInUserAnotherAccXpath")).click();
			driver.findElement(getElement("googleSignInEmailId")).clear();
			driver.findElement(getElement("googleSignInEmailId")).sendKeys(GoogleEmail);
			driver.findElement(getElement("googleSignInNextId")).click();
		} catch (Exception e) {
			driver.findElement(getElement("googleSignInEmailId")).clear();
			driver.findElement(getElement("googleSignInEmailId")).sendKeys(GoogleEmail);
			driver.findElement(getElement("googleSignInNextId")).click();
		}

		Thread.sleep(3000);
		driver.findElement(getElement("googleSignInPasswordName")).clear();
		driver.findElement(getElement("googleSignInPasswordName")).sendKeys(GooglePassword);
		driver.findElement(getElement("googleSignInPasswordNextId")).click();
		Thread.sleep(3000);
		try {

			new WebDriverWait(driver, 15).until(ExpectedConditions.numberOfWindowsToBe(1));
			driver.switchTo().window(driver.getWindowHandles().toArray()[0].toString());
			new WebDriverWait(driver, 10)
					.until(ExpectedConditions.visibilityOfElementLocated(By.id("header-account-menu-signed-in")));
			log1.info("Google signed in successfully");
            log1.pass("Google Signed in Successful");
			Thread.sleep(3000);

			System.out.println("Successfully signed in ");

			driver.findElement(getElement("normalSigninAccClickId")).click();
			Thread.sleep(3000);
			driver.findElement(getElement("SignOutId")).click();
			Thread.sleep(3000);
			log1.info("Google signed out successfully");
			driver.get("http://accounts.google.com");
			driver.manage().deleteAllCookies();
			driver.navigate().refresh();
		} catch (Exception w) {
			log1.fail("Google signed in failed");
			throw new AssertionError("Google Login Failed");
		}
	}

	public void fbSignIn(String Email, String Password, ExtentTest log1) throws InterruptedException {
		log1.info("Facebook Signin");
		driver.findElement(getElement("accountId")).click();
		driver.findElement(getElement("createAcc")).click();
		Thread.sleep(2000);
		driver.findElement(getElement("CreateAccFbId")).click();
		String pa1 = driver.getWindowHandle();
		Set<String> all1 = driver.getWindowHandles();
		driver.switchTo().window(driver.getWindowHandles().toArray()[1].toString());

		driver.findElement(getElement("FbLoginEmailId")).sendKeys(Email);
		driver.findElement(getElement("FbLoginPassId")).sendKeys(Password);
		driver.findElement(getElement("FbLoginClickId")).click();
		String titleSignin = "Expedia Travel: Vacations, Cheap Flights, Airline Tickets & Airfares";

		if (driver.getWindowHandles().size() > 1) {
			log1.fail("Signed out failed through facebook");
			Assert.assertEquals(titleSignin, driver.getTitle());
		}

		else {
			driver.switchTo().window(driver.getWindowHandles().toArray()[0].toString());
			System.out.println("Successfully signed in ");
			Thread.sleep(5000);
			log1.info("Signed in successfully through facebook");
			log1.pass("Signed in successfully through facebook");
			Assert.assertEquals(titleSignin, driver.getTitle());
			driver.findElement(getElement("normalSigninAccClickId")).click();
			Thread.sleep(2000);
			driver.findElement(getElement("SignOutId")).click();
			Thread.sleep(2000);
			log1.info("Signed out successfully through facebook");
		}

	}

//	public void fbSignOut() {
//		driver.switchTo().window(driver.getWindowHandles().toArray()[0].toString());
//		try {
//			System.out.println("Successfully signed in ");
//			Thread.sleep(3000);
//			driver.findElement(getElement("normalSigninAccClickId")).click();
//			Thread.sleep(2000);
//			driver.findElement(getElement("SignOutId")).click();
//			Thread.sleep(5000);
//		} catch (InterruptedException e) {
//			e.printStackTrace();
//		}
//	}

}
