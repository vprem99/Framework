package com.expedia.util;

import java.io.FileInputStream;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelFileReader {
	Workbook wb;

	public ExcelFileReader(String fileNameWithPath) {
		try {
			FileInputStream File_In = new FileInputStream(fileNameWithPath);
			if (fileNameWithPath.endsWith(".xlsx")) {
				wb = new XSSFWorkbook(File_In);
			} else if (fileNameWithPath.endsWith(".xls")) {
				wb = new HSSFWorkbook(File_In);
			}
		} catch (Exception E) {
			System.out.println("Error with file connection " + E.getMessage());
		}
	}

	public String getCellData(String sheetName, int row, int col) {
		System.out.println(row + " " + col);
		String data = wb.getSheet(sheetName).getRow(row).getCell(col).toString();
		return data;
	}

	public int getRowNum(String sheetName) {
		return wb.getSheet(sheetName).getLastRowNum();
	}
	public String[][] getAllData(String sheetName, int row, int col) {
		String data[][] = new String[row][col]; // Exact Number (Not index)

		// 3
		for (int i = 1; i <= row; i++) // Rows
		{
			for (int j = 0; j < col; j++) {
				data[i - 1][j] = getCellData(sheetName, i, j);
			}
		}
		return data;
	}
}
