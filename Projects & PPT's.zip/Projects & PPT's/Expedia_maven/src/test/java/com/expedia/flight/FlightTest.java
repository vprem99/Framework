package com.expedia.flight;

import org.testng.annotations.Test;

import com.expedia.util.Base;
import com.expedia.util.ExcelFileReader;

import org.testng.annotations.DataProvider;

public class FlightTest extends Base{
	
  @Test(dataProvider = "flight")
  public void flight(String origin,String destination,String journeyDate,String lastname,String firstname,
		  String phoneNumber,String dob_d,String dob_m,String dob_y,
		  String cardNumber,String card_m,String card_y,String cvv,String street,String city,String zipcode) throws Exception{//(Integer n, String s) {
	  Flight fl = new Flight(driver);
		log1 = extend.createTest("Flight Booking");
//		driver.get(p.getProperty("url"));
		fl.flightSearch(p.getProperty("url"), origin, destination, journeyDate,log1);
		fl.selectFlight(log1);
		fl.customerDetails(  lastname, firstname,
				   phoneNumber, dob_d, dob_m, dob_y,log1);
		fl.cardDetails( cardNumber, card_m, card_y, cvv,street, city, zipcode,log1);
  }

  @DataProvider
	public Object[][] flight() {

		ExcelFileReader ex = new ExcelFileReader(p.getProperty("filePath"));

		int row = ex.getRowNum(p.getProperty("Flight"));
		String[][] da = new String[row ][16];
		for (int i = 0; i < row ; i++) {

			da[i][0] = ex.getCellData(p.getProperty("Flight"), i + 1, 0);
			da[i][1] = ex.getCellData(p.getProperty("Flight"), i + 1, 1);
			da[i][2] = ex.getCellData(p.getProperty("Flight"), i + 1, 2);
			da[i][3] = ex.getCellData(p.getProperty("Flight"), i + 1, 3);
			da[i][4] = ex.getCellData(p.getProperty("Flight"), i + 1, 4);
			da[i][5] = ex.getCellData(p.getProperty("Flight"), i + 1, 5);
			da[i][6] = ex.getCellData(p.getProperty("Flight"), i + 1, 6);
			da[i][7] = ex.getCellData(p.getProperty("Flight"), i + 1, 7);
			da[i][8] = ex.getCellData(p.getProperty("Flight"), i + 1, 8);
			da[i][9] = ex.getCellData(p.getProperty("Flight"), i + 1, 9);
			da[i][10] = ex.getCellData(p.getProperty("Flight"), i + 1, 10);
			da[i][11] = ex.getCellData(p.getProperty("Flight"), i + 1, 11);
			da[i][12] = ex.getCellData(p.getProperty("Flight"), i + 1, 12);
			da[i][13] = ex.getCellData(p.getProperty("Flight"), i + 1, 13);
			da[i][14] = ex.getCellData(p.getProperty("Flight"), i + 1, 14);
			da[i][15] = ex.getCellData(p.getProperty("Flight"), i + 1, 15);
	}

		return da;
	}

  
}
