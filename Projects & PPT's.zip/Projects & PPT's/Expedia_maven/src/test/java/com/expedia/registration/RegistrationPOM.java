package com.expedia.registration;

import java.util.Properties;

import java.util.Set;

import org.apache.poi.ss.usermodel.Workbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.aventstack.extentreports.ExtentTest;
import com.expedia.util.BasePOM;

public class RegistrationPOM extends BasePOM {

	public RegistrationPOM(WebDriver driver) {
		super(driver);
	}

	public void creatingAcc(String Firstname, String Surname, String EmailAddress, String Createpass, ExtentTest log1) throws Exception {
		log1.info("Registration Process");
		Thread.sleep(5000);
		driver.findElement(getElement("accountId")).click();
		//driver.findElement(By.id("header-account-menu")).click();
		driver.findElement(getElement("createAcc")).click();

		new WebDriverWait(driver, 10)
				.until(ExpectedConditions.visibilityOfElementLocated(getElement("createAccFirstNameId")));
		
		driver.findElement(getElement("createAccFirstNameId")).clear();
		driver.findElement(getElement("createAccSurnameId")).clear();
		driver.findElement(getElement("createAccEmailId")).clear();
		driver.findElement(getElement("createAccPassId")).clear();

		driver.findElement(getElement("createAccFirstNameId")).sendKeys(Firstname);
		driver.findElement(getElement("createAccSurnameId")).sendKeys(Surname);
		driver.findElement(getElement("createAccEmailId")).sendKeys(EmailAddress);
		driver.findElement(getElement("createAccPassId")).sendKeys(Createpass);
		driver.findElement(getElement("createAccCheckBoxId")).click();
		driver.findElement(getElement("createAccSignupId")).click();
		Thread.sleep(60000); 
		
		try{
			
		driver.findElement(getElement("createAccContinueClickId")).click();
		driver.switchTo().window(driver.getWindowHandles().toArray()[0].toString());
		Thread.sleep(4000);
		driver.findElement(getElement("normalSigninAccClickId")).click();
		driver.findElement(getElement("SignOutId")).click();
		log1.pass("Successfully Registred");

		}
		catch(Exception e)
		{
			System.out.println("before log");
			log1.fail("Registration failed");
			System.out.println("after log");
			throw new AssertionError("Registration Failed");
			
		}
	}

}