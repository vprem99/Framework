package com.expedia.signIn;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.expedia.util.Base;
import com.expedia.util.ExcelFileReader;



public class SignInTest extends Base {
	@BeforeMethod
	public void beforeMethod() {
		if (driver.getWindowHandles().size() > 1) {
			driver.switchTo().window(driver.getWindowHandles().toArray()[1].toString());
			driver.close();
			driver.switchTo().window(driver.getWindowHandles().toArray()[0].toString());
			driver.manage().deleteAllCookies();
			driver.navigate().refresh();
		}
	}

	 @Test(dataProvider = "emailSignInDetails")
	 public void normalSign(String Email,String Password) throws Exception {

	 driver.get(p.getProperty("url"));
	 SignInPOM si = new SignInPOM(driver);
	 log1 = extend.createTest("LoginProcess");
	 si.normalSignIn(Email,Password,log1);
	 
	 }

	@Test(dataProvider = "fbSignInDetails")
	public void facebookSign(String Email, String Password, String Valid) throws Exception {
		driver.get(p.getProperty("url"));
		log1 = extend.createTest("LoginProcess through Facebook");
		SignInPOM si = new SignInPOM(driver);
		si.fbSignIn(Email, Password, log1);
	}


	@Test(dataProvider = "googleSignInDetails")
	 public void googleSign(String GoogleEmail,String GooglePassword) throws
	 Exception{
	 driver.get(p.getProperty("url"));
	 SignInPOM si = new SignInPOM(driver);
	 log1 = extend.createTest("Google Signin Process");
	 si.googleSignIn(GoogleEmail, GooglePassword,log1);
	 System.out.println(GoogleEmail+" "+GooglePassword);
	 }

	@DataProvider
	public Object[][] googleSignInDetails() {

		ExcelFileReader ex = new ExcelFileReader(p.getProperty("filePath"));
		int row = ex.getRowNum(p.getProperty("GoogleSheet"));
		String[][] da = new String[row][2];
		for (int i = 0; i < da.length; i++) {

			da[i][0] = ex.getCellData(p.getProperty("GoogleSheet"), i + 1, 0);
			da[i][1] = ex.getCellData(p.getProperty("GoogleSheet"), i + 1, 1);

		}
		return da;
	}

	@DataProvider
	public Object[][] emailSignInDetails() {

		ExcelFileReader ex = new ExcelFileReader(p.getProperty("filePath"));

		int row = ex.getRowNum(p.getProperty("NormalSignInSheetName"));
		String[][] da = new String[row][2];
		for (int i = 0; i < row; i++) {

			da[i][0] = ex.getCellData(p.getProperty("NormalSignInSheetName"), i + 1, 0);
			da[i][1] = ex.getCellData(p.getProperty("NormalSignInSheetName"), i + 1, 1);

		}

		return da;
	}

	@DataProvider
	public Object[][] fbSignInDetails() {

		ExcelFileReader ex = new ExcelFileReader(p.getProperty("filePath"));
		int row = ex.getRowNum(p.getProperty("FaceBookSheet"));
		String[][] da = new String[row][3];
		for (int i = 0; i < da.length; i++) {

			da[i][0] = ex.getCellData(p.getProperty("FaceBookSheet"), i + 1, 0);
			da[i][1] = ex.getCellData(p.getProperty("FaceBookSheet"), i + 1, 1);
			da[i][2] = ex.getCellData(p.getProperty("FaceBookSheet"), i + 1, 2);


		}
		return da;
	}
}
