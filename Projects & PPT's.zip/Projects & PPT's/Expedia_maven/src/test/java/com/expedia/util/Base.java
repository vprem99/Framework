package com.expedia.util;

import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

import atu.testrecorder.ATUTestRecorder;
import atu.testrecorder.exceptions.ATUTestRecorderException;

import org.testng.annotations.BeforeTest;

import java.io.FileInputStream;
import java.text.DateFormat;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.ITestResult;
import org.testng.Reporter;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeSuite;

public class Base {
	public WebDriver driver;
	public Properties p;
	public BasePOM base;
	public ExtentReports extend;
	public ExtentTest log1;
	public ATUTestRecorder recorder;

	@BeforeSuite
	public void bs() throws ATUTestRecorderException {
		recorder = new ATUTestRecorder("D:\\ScriptVideos\\", "TestVideo-", false);
		recorder.start();

	}

	@BeforeTest
	public void beforeTest() {

		extend = new ExtentReports();
		ExtentHtmlReporter html = new ExtentHtmlReporter(".\\log.html");
		html.setAppendExisting(true);
		extend.attachReporter(html);
		p = new Properties();
		try {
			p.load(new FileInputStream(".\\Settings1.property"));
		} catch (Exception e) {
			System.out.println("not working");
		}
		if (p.getProperty("browser").equalsIgnoreCase("chrome")) {
			System.setProperty("webdriver.chrome.driver", "D:\\1SelJars\\chromedriver_win32\\chromedriver.exe");
			driver = new ChromeDriver();
		} else if (p.getProperty("browser").equalsIgnoreCase("firefox")) {
			System.setProperty("webdriver.gecko.driver", "D:\\1SelJars\\geckodriver-v0.26.0-win64\\geckodriver.exe");
			driver = new FirefoxDriver();
		}
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);

		base = new BasePOM(driver);
	}

	@AfterTest
	public void afterTest() throws InterruptedException {
		driver.quit();
	}

	@AfterMethod
	public void afterMethod(ITestResult result) throws Exception {

		System.setProperty("org.uncommons.reportng.escape-output", "false");

		System.out.println("In After Method");

		if (result.getStatus() == ITestResult.FAILURE) {

			String path = base.getSnap(System.getProperty("user.dir") + "\\Screenshots", result.getName());
			System.out.println("screen shot taken");
			System.out.println(path + " YYY");
			Reporter.log("Click to see Screenshot");
			Reporter.log("<a target=\"_blank\" href=" + path + ">Screenshot</a>");
			Reporter.log("<br>");
			Reporter.log("<br>");
			Reporter.log(
					"<a target=\"_blank\" href=" + path + "><img src=" + path + " height=200 width=200></img></a>");
		}
		extend.flush();

	}

	@AfterSuite
	public void af() throws ATUTestRecorderException {
		recorder.stop();
	}
}
