package com.expedia.registration;

import org.testng.annotations.Test;

import com.expedia.util.Base;
import com.expedia.util.ExcelFileReader;

import java.io.FileInputStream;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.testng.annotations.DataProvider;

public class RegistrationTest extends Base {

	@Test(dataProvider = "regEmail")
	public void f(String Firstname, String Surname, String EmailAddress, String Createpass) throws Exception {
		RegistrationPOM rt = new RegistrationPOM(driver);
		driver.get(p.getProperty("url"));
		log1 = extend.createTest("Registration Process");
		rt.creatingAcc(Firstname, Surname, EmailAddress, Createpass,log1);
	}

	@DataProvider
	public Object[][] regEmail() {

		ExcelFileReader ex = new ExcelFileReader(p.getProperty("filePath"));
		int row = ex.getRowNum(p.getProperty("emailReg"));
		String[][] obj = new String[2][4];
		for (int i = 0; i < obj.length; i++) {
			obj[i][0] = ex.getCellData(p.getProperty("emailReg"), i + 1, 0);
			obj[i][1] = ex.getCellData(p.getProperty("emailReg"), i + 1, 1);
			obj[i][2] = ex.getCellData(p.getProperty("emailReg"), i + 1, 2);
			obj[i][3] = ex.getCellData(p.getProperty("emailReg"), i + 1, 3);
		}
		return obj;
	}
}
