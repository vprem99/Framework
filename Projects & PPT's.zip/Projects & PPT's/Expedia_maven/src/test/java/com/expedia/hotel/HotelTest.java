package com.expedia.hotel;

import org.testng.annotations.Test;

import com.expedia.util.Base;
import com.expedia.util.ExcelFileReader;

import java.io.FileInputStream;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.testng.annotations.DataProvider;

public class HotelTest extends Base {
	
	@Test(dataProvider="hotel")
	public void hotelBooking(String Destination,String CheckIn,String CheckOut,
			String ContName,String MobileNum,String CardNum,String Exp_M,String Exp_y,String cvv ) throws Exception{
		log1 = extend.createTest("Hotel Search");

		HotelPom rt = new HotelPom(driver);
		rt.hotelSearch(p.getProperty("url"),Destination,CheckIn,CheckOut,log1);
		rt.hotelClick(log1);
		rt.hotelExplore(log1);
		rt.contactDetails( ContName, MobileNum,log1);
		rt.cardDetails( CardNum, Exp_M, Exp_y, cvv,log1);
	}
	@DataProvider
	public Object[][] hotel() {

		ExcelFileReader ex = new ExcelFileReader(p.getProperty("filePath"));

		int row = ex.getRowNum(p.getProperty("Hotel"));
		String[][] da = new String[2 ][9];
		for (int i = 0; i < da.length; i++) {

			da[i][0] = ex.getCellData(p.getProperty("Hotel"), i + 1, 0);
			da[i][1] = ex.getCellData(p.getProperty("Hotel"), i + 1, 1);
			da[i][2] = ex.getCellData(p.getProperty("Hotel"), i + 1, 2);
			da[i][3] = ex.getCellData(p.getProperty("Hotel"), i + 1, 3);
			da[i][4] = ex.getCellData(p.getProperty("Hotel"), i + 1, 4);
			da[i][5] = ex.getCellData(p.getProperty("Hotel"), i + 1, 5);
			da[i][6] = ex.getCellData(p.getProperty("Hotel"), i + 1, 6);
			da[i][7] = ex.getCellData(p.getProperty("Hotel"), i + 1, 7);
			da[i][8] = ex.getCellData(p.getProperty("Hotel"), i + 1, 8);


		}

		return da;
	}
	
}
