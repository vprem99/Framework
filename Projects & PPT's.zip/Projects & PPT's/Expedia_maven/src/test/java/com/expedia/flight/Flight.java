package com.expedia.flight;

import java.io.FileInputStream;
import java.util.Properties;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.ExtentTest;
import com.expedia.util.BasePOM;



public class Flight extends BasePOM {
	
	public Flight(WebDriver driver) {
		super(driver);
	}

	public void flightSearch(String url,String origin,String destination,String journeyDate, ExtentTest log1) throws Exception {
		log1.info("Flight Booking");
		if(driver.getWindowHandles().size()>1){
			driver.switchTo().window(driver.getWindowHandles().toArray()[1].toString()).close();

			driver.switchTo().window(driver.getWindowHandles().toArray()[0].toString());
		}
		driver.get(url);

		driver.findElement(getElement("flightOption")).click();

		driver.findElement(getElement("journeyType")).click();
		driver.findElement(getElement("origin")).clear();
		driver.findElement(getElement("origin")).sendKeys(origin);
		driver.findElement(getElement("destination")).clear();
		driver.findElement(getElement("destination")).sendKeys(destination);
		driver.findElement(getElement("journeyDate")).clear();
		driver.findElement(getElement("journeyDate")).sendKeys(journeyDate);
		driver.findElement(getElement("passengersSelecion")).click();
		driver.findElement(getElement("search")).click();
	}
	public void selectFlight( ExtentTest log1) throws Exception {
		try{
		driver.findElement(getElement("selectFlight")).click();
		Thread.sleep(3000);
		driver.findElement(getElement("noThanks")).click();
		}
		catch(Exception e){
			log1.fail("Flight is not getting Selected");
			throw new AssertionError("DOB sending Error");
		}
	}
	public void customerDetails(String lastname,String firstname,
			  String phoneNumber,String dob_d,String dob_m,String dob_y, ExtentTest log1) throws Exception {
		String pa = driver.getWindowHandle();
		Set<String> all = driver.getWindowHandles();
		for (String e : all) {
			if (!(e.equals(pa))) {
				driver.switchTo().window(e);
			}
		}
		driver.findElement(getElement("confirmFlight")).click();
		WebElement title=driver.findElement(getElement("title"));
		Select Titel=new Select(title);
		Titel.selectByIndex(1);
		driver.findElement(getElement("lastname")).sendKeys(lastname);
		driver.findElement(getElement("firstname")).sendKeys(firstname);
		driver.findElement(getElement("phoneNumber")).sendKeys(phoneNumber);
		try{
		WebElement month=driver.findElement(getElement("dob_m"));
		Select Month=new Select(month);
		Month.selectByIndex(Integer.parseInt(dob_m));
		WebElement day=driver.findElement(getElement("dob_d"));
		Select Day=new Select(day);
		Day.selectByValue(dob_d);
		WebElement year=driver.findElement(getElement("dob_y"));
		Select Year=new Select(year);
		Year.selectByValue(dob_y);
		}
		catch(Exception e){
//			log1.fail("DOB is not Working");
//			throw new AssertionError("DOB sending Error");
			
		}
	
	}
	public void cardDetails(String cardNumber,String card_m,String card_y,String cvv,String street,String city,String zipcode, ExtentTest log1) throws Exception {
		
		try{
		driver.findElement(getElement("cardNumber")).clear();
		driver.findElement(getElement("cardNumber")).sendKeys(cardNumber);
		driver.findElement(getElement("cvv")).sendKeys(cvv);
		driver.findElement(getElement("street")).sendKeys(street);
		driver.findElement(getElement("city")).sendKeys(city);
		driver.findElement(getElement("zipcode")).sendKeys(zipcode);
		}
		catch(Exception e){
			log1.fail("Experiy is not Working");
			throw new AssertionError("DOB sending Error");			
		}
		
		 driver.close();
		 driver.switchTo().window(driver.getWindowHandles().toArray()[0].toString());
		log1.pass("Flight Sucessfully Booked");
	}


	
}
