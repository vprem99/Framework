package com.expedia.util;

import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Date;
import java.util.Properties;

import javax.imageio.ImageIO;

import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.io.FileHandler;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

public class BasePOM {
	public WebDriver driver;
	public Properties prop;

	public BasePOM(WebDriver driver) {
		this.driver = driver;
		prop = new Properties();
		try {
			prop.load(new FileInputStream(".\\OR2.property"));
		} catch (Exception E) {
			System.out.println("Error with File Loading");
		}

	}

	public By getElement(String element) {
		String Locator = prop.getProperty(element);
		String LocatorType = Locator.split(":=")[0];
		String LocatorValue = Locator.split(":=")[1];
		if (LocatorType.equalsIgnoreCase("id")) {
			System.out.println();
			return By.id(LocatorValue);
		} else if (LocatorType.equalsIgnoreCase("name")) {
			return By.name(LocatorValue);
		} else if (LocatorType.equalsIgnoreCase("xpath")) {
			return By.xpath(LocatorValue);
		} else if (LocatorType.equalsIgnoreCase("linkText")) {
			return By.linkText(LocatorValue);
		} else if (LocatorType.equalsIgnoreCase("css")) {
			return By.linkText(LocatorValue);
		} else {
			System.out.println("kgsdfjgdfsjgk");
			System.out.println(LocatorType);
			return null;
		}
	}

	public String getSnap(String Location, String name) {
		System.out.println(driver + "DD");
		String D = new Date().toString().replaceAll(" ", "_").replaceAll(":", "_");
		String path = Location + "\\" + name + D + ".png";
		System.out.println();
		try {

			BufferedImage image = new Robot()
					.createScreenCapture(new Rectangle(Toolkit.getDefaultToolkit().getScreenSize()));

			// This will store screenshot on Specific location
			ImageIO.write(image, "png", new File(path));
			// FileHandler.copy(src, new File(path));
		} catch (Exception e) {
			System.out.println("Error with Taking ScreenShot " + e.getMessage());
		}
		return path;
	}
}
