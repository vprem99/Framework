package Executes;

import org.testng.annotations.Test;

import com.ibibo.flights.FlightPOM;

import util.Base;

public class ExecuteFlight extends Base{
  @Test
  public void f()
  {
	  driver.get(prop.getProperty("url"));
	  FlightPOM FP=new FlightPOM(driver);
	  FP.searchFlight();
  }
}
