package com.ibibo.flights;

import org.openqa.selenium.WebDriver;

import util.BasePOM;

public class FlightPOM extends BasePOM{

	public FlightPOM(WebDriver driver) {
		super(driver);
	}

	public void searchFlight()
	{
	
		prop.getElementProperty("fromFlight").sendKeys("Mumbai");
		
		
		
	}
	
	
	
}
