package util;

import java.io.FileInputStream;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

public class Base {
	public WebDriver driver;
	public Properties prop;
	protected static ExtentTest testLog;
	protected static ExtentReports extentReporter;
	

	@BeforeTest(alwaysRun=true)
	public void beforeTest() throws Exception {
		prop = new Properties();
		prop.load(new FileInputStream(".\\config.property"));

		if (prop.getProperty("browser").equalsIgnoreCase("chrome")) {
			System.setProperty("webdriver.chrome.driver", ".\\Drivers\\chromedriver.exe");
			driver = new ChromeDriver();
		}
		if (prop.getProperty("browser").equalsIgnoreCase("firefox")) {
			System.setProperty("webdriver.gecko.driver", ".\\Drivers\\geckodriver.exe");
			driver = new FirefoxDriver();
		}
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		//Implicit Wait
		extentReporter=new ExtentReports();
		extentReporter.attachReporter(new ExtentHtmlReporter("GoIbibo.html"));
	}

	@AfterTest(alwaysRun=true)
	public void afterTest() {
		// driver.quit();
	}

	public WebElement getElement(String Key) {
		String Locator = prop.getProperty(Key);
		String LocatorType = Locator.split(":=")[0]; // id
		String LocatorValue = Locator.split(":=")[1];// q

		WebElement E = null;
		switch (LocatorType) {
		case "id":
			E = driver.findElement(By.id(LocatorValue));
			break;
		case "name":
			E = driver.findElement(By.name(LocatorValue));
			break;
		case "link":
			E = driver.findElement(By.linkText(LocatorValue));
			break;
		default:
			System.out.println("Invalid Locator Type");
		}
		return E;
	}
}
