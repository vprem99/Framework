package util;

import org.openqa.selenium.WebDriver;

public class BasePOM 
{
	WebDriver driver;
	public ReadingProperty prop;
	Keywords key;
	public BasePOM(WebDriver driver)
	{
		this.driver=driver;
		prop=new ReadingProperty(".\\OR.property", driver);
		key=new Keywords(driver);
	}

}
