package util;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class ReadingProperty 
{	Properties prop;
	WebDriver driver;
	ReadingProperty(String Location,WebDriver driver)
	{
		this.driver=driver;
		prop=new Properties();
		
		
		try {
			prop.load(new FileInputStream(Location));
		} catch (IOException e) {
		System.out.println("Error with Connection with property file");
			e.printStackTrace();
		}
		
	}
	
	
	public String getProperty(String key)
	{
		
		return		prop.getProperty(key);
		
	}
	
	public WebElement getElementProperty(String key)
	{
		
		String Locator = prop.getProperty(key);
		String LocatorType = Locator.split(":=")[0]; // id
		String LocatorValue = Locator.split(":=")[1];// q

		WebElement E = null;
		switch (LocatorType) {
		case "id":
			E = driver.findElement(By.id(LocatorValue));
			break;
		case "name":
			E = driver.findElement(By.name(LocatorValue));
			break;
		case "link":
			E = driver.findElement(By.linkText(LocatorValue));
			break;
		default:
			System.out.println("Invalid Locator Type");
		}
		return E;
	}
	
	

}
