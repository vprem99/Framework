package util;

import java.io.FileInputStream;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelReader {
	Workbook wb;
	public ExcelReader(String FileName) {
		try {
			FileInputStream IP = new FileInputStream(FileName);
			if (FileName.endsWith(".xls")) {
				wb = new HSSFWorkbook(IP);
			} else if (FileName.endsWith(".xlsx")) {
				wb = new XSSFWorkbook(IP);
			} else
				System.out.println("Invalid File Format");

		} catch (Exception E) {
			System.out.println("Error with File Connection "+E.getMessage());
		}
	}
	
	public String getData(String SheetName,int Row,int Col)
	{
	String data=wb.getSheet(SheetName).getRow(Row).getCell(Col).toString();
	return data;
	}
	
	public int getRowNum(String SheetName)
	{
	int row=wb.getSheet(SheetName).getLastRowNum();
	return row;
	}
	
	public int getColNum(String SheetName)
	{
	int col=wb.getSheet(SheetName).getRow(0).getLastCellNum();
	return col-1;
	}
	
	public String[][] getSheetData(String SheetName,int rowIndex,int colIndex)
	{
		String allData[][]=new String[rowIndex][colIndex+1];
		
		for(int i=1;i<=rowIndex;i++)  // Row
		{
			for(int j=0;j<=colIndex;j++)  //Columns
			{
				// i=1			j=0
				// allData[0][0]=getData(SheetName, 1, 0); //
				// allData[0][1]=getData(SheetName, 1, 1); //
				allData[i-1][j]=getData(SheetName, i, j); //  
			}
		}
			return allData;
	}
}