package util;

public class Execute {
	public static void main(String[] args) {
		ExcelReader ex = new ExcelReader("C:\\Users\\vshadmin\\Desktop\\data.xls");
		String data[][]=ex.getSheetData("Sheet1", 5, 1);
		
		
/*		for (int i = 0; i <= ex.getRowNum("sheet1"); i++) {
			System.out.println(ex.getData("sheet1", i, 0));
		}
*/	
	/*	
	for(int i=0;i<data.length;i++)
	{
		System.out.println(data[i][0]);
		System.out.println(data[i][1]);
		
	}*/

	
	int age[]=new int[4];  
	
	for(int i=0;i<=3;i++)
	{
		System.out.println(age[i]);
	}
	
	
	}
}