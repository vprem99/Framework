package util;

import java.io.File;
import java.io.IOException;
import java.util.Date;

import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.io.FileHandler;
import org.openqa.selenium.support.ui.Select;

public class Keywords {
	WebDriver driver;
	public Keywords(WebDriver driver) {
		this.driver = driver;
	}
	public void getURL(String URL) {
		driver.get(URL);
	}
	public void click(String Locator) { // id:=q
		String LocatorType = Locator.split(":=")[0];
		String LocatorValue = Locator.split(":=")[1];
		switch (LocatorType) {
		case "id":
			driver.findElement(By.id(LocatorValue)).click();
			break;
		case "xpath":
			driver.findElement(By.xpath(LocatorValue)).click();
			break;
		default:
			System.out.println("invalid Locator Type");
		}
	}

	public void type(String Locator, String data) {
		// id:=q
		String LocatorType = Locator.split(":=")[0];
		String LocatorValue = Locator.split(":=")[1];
		switch (LocatorType) {
		case "id":
			driver.findElement(By.id(LocatorValue)).sendKeys(data);
			break;
		case "xpath":
			driver.findElement(By.xpath(LocatorValue)).sendKeys(data);
			break;
		default:
			System.out.println("invalid Locator Type");
		}
	}
	public void getSceenShot(String name) {
		Date date = new Date();
		String newDate = date.toString().
				replaceAll(" ", "_").replaceAll(":", "_");
		TakesScreenshot t = (TakesScreenshot) driver;
		File src = t.getScreenshotAs(OutputType.FILE);
		try {
			FileHandler.copy(src, new File(".\\"+name+newDate+".png"));
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	public void selectDropDown(String Locator, String data) {
		String LocatorType = Locator.split(":=")[0];
		String LocatorValue = Locator.split(":=")[1];
		WebElement E=null;	
		switch (LocatorType) {
		case "id":
			E=driver.findElement(By.id(LocatorValue));
			break;
		case "xpath":
			E=driver.findElement(By.xpath(LocatorValue));
			break;
		default:
			System.out.println("invalid Locator Type");
		}
		new Select(E).selectByVisibleText(data);
	}
	
	public void maxiMize()
	{
		driver.manage().window().maximize();
	}
}
