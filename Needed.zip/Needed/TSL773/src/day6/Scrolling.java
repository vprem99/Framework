package day6;


import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import util.Base;

public class Scrolling extends Base{
  @Test
  public void scrollingExample() throws Exception
  {
	  System.out.println(prop.getProperty("url"));
	  driver.get(prop.getProperty("url"));
 
	  
	  
	  //FirefoxDriver webdriver, TakesScreenShot, JavaScriptExecutor
	  JavascriptExecutor JS=(JavascriptExecutor)driver;
	   Thread.sleep(3000);
	   System.out.println(prop.getProperty("seleniumBlog"));
	 // WebElement E=driver.findElement(By.linkText(prop.getProperty("seleniumBlog")));
	  
	   WebElement E=getElement("seleniumBlog");
	   
	   JS.executeScript("arguments[0].scrollIntoView();", E);
	  
	   Thread.sleep(3000);

	  JS.executeScript("window.scrollBy(0,-300)");

	   Thread.sleep(3000);
	  JS.executeScript("window.scrollBy(0, document.body.scrollHeight)");
	  Thread.sleep(3000);
	  JS.executeScript("window.scrollBy(0, -document.body.scrollHeight)");
	 
	  getElement("search").sendKeys("LTI");
  }
  
 
}
