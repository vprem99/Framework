package day6Junit;

import static org.junit.Assert.*;

import java.util.Set;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.Cookie;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class cookieExample {

static WebDriver driver;
	
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		System.setProperty("webdriver.chrome.driver", ".\\Drivers\\chromedriver.exe");
		driver=new ChromeDriver();
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	driver.quit();
	}

	@Test
	public void GoogleCookieTest() {
	driver.get("http://google.com");
	System.out.println("=============Google Cookies================="); 

	Set<Cookie> allCK=driver.manage().getCookies();
	for(Cookie C:allCK)
	{
		System.out.println("Name of Cookie "+C.getName());
		System.out.println("Domain of Cookie "+C.getDomain());
		System.out.println("Path of Cookie "+C.getPath());
		System.out.println("Value of Cookie "+C.getValue());
		System.out.println("Expiry of Cookie "+C.getExpiry());
	}

	}
	
	
	@Test
	public void OracleCookieTest() {
	driver.get("http://127.0.0.1:8080/htmldb/f?p=4550:11:16255835094829154782::NO:::");
	driver.findElement(By.name("p_t01")).sendKeys("hr");
	driver.findElement(By.name("p_t02")).sendKeys("hr");
	driver.findElement(By.cssSelector("input[type='BUTTON']")).click();
	System.out.println("=============Oracle Cookies================="); 
	
	Set<Cookie> allCK=driver.manage().getCookies();
	for(Cookie C:allCK)
	{
		System.out.println("Name of Cookie "+C.getName());
		System.out.println("Domain of Cookie "+C.getDomain());
		System.out.println("Path of Cookie "+C.getPath());
		System.out.println("Value of Cookie "+C.getValue());
		System.out.println("Expiry of Cookie "+C.getExpiry());
	}
	driver.manage().deleteAllCookies();
	driver.navigate().refresh();
	assertEquals("All Cookies are not deleted","HTML DB Login", driver.getTitle());;
	}
}