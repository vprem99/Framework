package day6Junit;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class All_AnotationJunit {

	@BeforeClass
	public static void setUpBeforeClass() throws Exception 
	{
		System.out.println("In Before Class");
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		System.out.println("In After Class");
	}

	@Before
	public void setUp() throws Exception {
		System.out.println("In Before method");
	}

	@After
	public void tearDown() throws Exception {
		System.out.println("In After method");
	}

	@Test
	public void test() {
		assertTrue("First Number is Less than Second Number",5>41);
	
	}
	
	@Test
	public void test2() {
		assertFalse("First Number is Greater than Second Number",51>41);
	
	}

}
