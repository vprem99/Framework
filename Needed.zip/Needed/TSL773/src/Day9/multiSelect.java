package Day9;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

import util.Base;

public class multiSelect extends Base {
  @Test
  public void f() 
  {
	  driver.get("file:///C:/Users/vshadmin/Desktop/multiselectDropDown.html");

	  Select s=new Select(driver.findElement(By.name("cars")));
	  s.selectByVisibleText("Saab");
	  s.selectByVisibleText("Opel");
	  
	  System.out.println(s.isMultiple());
	  
	  
	  
  
  
  
  }
}
