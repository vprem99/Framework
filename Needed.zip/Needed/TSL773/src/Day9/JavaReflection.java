package Day9;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Parameter;
import java.lang.reflect.Type;

import org.testng.annotations.Test;

public class JavaReflection {
  @Test
  public void f() throws Exception
  {
	  /*For inspecting any kind of Java Class i.e Knowing number of Method,
	   * variables, Superclass etc.
	   * 
	   * */
	  	
	Class C=  Class.forName("org.openqa.selenium.chrome.ChromeDriver");
	 
	System.out.println("Super class is "+C.getSuperclass());
	
	Field[] Fl=C.getDeclaredFields();
	System.out.println("Total Fields are "+Fl.length);
	for(Field F: Fl)
	{
		System.out.println(F.getName());
	}
	
	Constructor[] CN=C.getDeclaredConstructors();
	System.out.println("Total Constructors are "+CN.length);
	for(Constructor CO: CN)
	{
		Class[] CC=CO.getParameterTypes();
		for(Class P:CC)
		{
			System.out.println(P.getName());
		}
	}
	
	Method[] MD= C.getMethods();
		for(Method M:MD)
		{
			System.out.println(M.getName());
			Parameter PM[]=M.getParameters();
			for(Parameter P:PM)
			{
				System.out.println(P.getParameterizedType()+" " );
				//System.out.print(P.getName()+" " );
			}
			
		}
		
	
	  
	  
	  
  }
}
