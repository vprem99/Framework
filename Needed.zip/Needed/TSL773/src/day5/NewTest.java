package day5;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class NewTest {
		@Test(dataProvider = "dp")
		public void DemoTest(String n, String s) 
		{
		}
		@DataProvider
		public Object[][] dp()
		{
			Object data[][]=new Object[2][2];
			return data;
		}
}
