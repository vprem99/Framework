package day5;

import java.io.File;
import java.util.Date;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.io.FileHandler;
import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import util.ExcelReader;

public class Para 
{
	WebDriver driver;
  @Test(dataProvider = "dp")
  public void LoginTest(String n, String s) 
  {
	  driver.get("http://127.0.0.1:8080/htmldb");
	  driver.findElement(By.name("p_t01")).sendKeys(n);
	  driver.findElement(By.name("p_t02")).sendKeys(s);
	  driver.findElement(By.cssSelector("input[type='BUTTON']")).click();
	  Assert.assertEquals(driver.getTitle(),"Oracle","Login Failed");
	  driver.findElement(By.linkText("Logout")).click();
  }
  
  
  @AfterMethod
  public void afterMethod(ITestResult I) throws Exception
  {
	 System.out.println("In After Method");
	 Date date=new Date();
	 String newDate= date.toString().replaceAll(" ", "_").replaceAll(":", "_");
	  if(I.getStatus()==ITestResult.FAILURE)
	  {
		File src=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		FileHandler.copy(src, new File(".\\"+I.getName()+newDate+".png"));
	  }
  }
  

  @DataProvider
  public Object[][] dp() 
  {
	  ExcelReader ex=new ExcelReader("C:\\Users\\vshadmin\\Desktop\\data.xls");
	  Object[][] data=ex.getSheetData("Sheet1", 4, 1);
	  
	  //	  Object[][] data=new Object[4][2];
	  /*data[0][0]="system";
	  data[0][1]="Newuser123";
	  data[1][0]="sdddys";
	  data[1][1]="Newuser123";
	  data[2][0]="hr";
	  data[2][1]="hr";
	  data[3][0]="ss";
	  data[3][1]="ss";*/
	  return data;
  }
  
  @BeforeTest
  public void beforeTest() 
  {
	 System.setProperty("webdriver.chrome.driver", ".\\Drivers\\chromedriver.exe"); 
	  driver=new ChromeDriver();
  }

  @AfterTest
  public void afterTest() 
  {
	  driver.quit();
  }

}
