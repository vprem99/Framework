package day5;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.htmlunit.HtmlUnitDriver;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class FirstNgScript
{
	WebDriver driver;
  @Test(priority=1)
  public void TitleTest()
  {
	  driver.get("http://www.google.com");
	  Assert.assertEquals(driver.getTitle(), "Google India");
	  
	  List<WebElement> ls=driver.findElements(By.tagName("a"));
	  ls.addAll(driver.findElements(By.xpath("//img")));
	  
  }
  
  @Test(priority=2)
  public void ImageTest()
  {
	 WebElement E=driver.findElement(By.cssSelector("img[title='Muthulakshmi Reddi�s 133rd Birthday']"));
	 Assert.assertEquals(E.isDisplayed(), true,"Image not displayed");
	 Assert.assertEquals(E.isEnabled(), true,"Image not Enabled");
	// Assert.assertEquals(E.isSelected(), true); 
	 //application for radio & checkbox
	 Assert.assertEquals(E.getAttribute("height"), "222","Image not having Proper height");
	 System.out.println(E.getAttribute("src"));
  }
  @BeforeTest
  public void beforeTest() 
  {
	/*  ChromeOptions op=new ChromeOptions();
	  op.addArguments("--headless");
	
	 System.setProperty("webdriver.chrome.driver", ".\\Drivers\\chromedriver.exe"); 
	 driver=new ChromeDriver(op);*/
	  
	  
	  driver=new HtmlUnitDriver(true);
	  //false > does not support JavaScript
	  //True > supports JavaScript
	  /* Default if you do not pass anything 
	  means it will not support JavaScript
	*/  
	  
	  
  }

  @AfterTest
  public void afterTest() 
  {
	  driver.quit();
  }

}
