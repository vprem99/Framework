package Day8;

import org.testng.annotations.Test;

import util.Base;
import util.Keywords;

public class ExecuteKeyWords extends Base{
  @Test
  public void f() 
  {
	  Keywords Key=new Keywords(driver);
	  Key.getURL("http://127.0.0.1:8080/htmldb/f?p=4550:11:12523182525177224194::NO:::");
	  Key.type("id:=P11_USERNAME", "sys");
	  Key.type("id:=P11_PASSWORD", "Newuser123");
	  Key.click("xpath:=//*[@value='Login']");
	  Key.getSceenShot("Login");
	  Key.maxiMize();
	  Key.click("xpath:=//a[text()='Logout']");
	  Key.click("xpath:=//a[text()='Login']");


  
  }
}
