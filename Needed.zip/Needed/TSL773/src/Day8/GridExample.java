package Day8;

import java.net.URL;

import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class GridExample {
	WebDriver driver;
	@Test
	public void f1() throws Exception {
		driver.get("http://google.com");
		Thread.sleep(5000);
	//	http://localhost:4444/grid/console
	}

	@BeforeTest
	@Parameters({"node","browser"})
	public void BeforeTest(String node,String browser) throws Exception {
		DesiredCapabilities dc=null;
		if(browser.equals("chrome"))
			 dc = DesiredCapabilities.chrome();
		else if(browser.equals("firefox"))
			 dc = DesiredCapabilities.firefox();

		
		dc.setPlatform(Platform.WINDOWS);
		driver = new RemoteWebDriver(new URL(node), dc);
	}

	@AfterTest
	public void AfterTest() {
		driver.quit();
	}
}