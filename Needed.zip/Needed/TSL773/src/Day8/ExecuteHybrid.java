package Day8;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import util.Base;
import util.ExcelReader;
import util.Keywords;

public class ExecuteHybrid extends Base {
	@Test(dataProvider = "dp")
	public void f(String Action, String Locator, String Data) {
		Keywords Key = new Keywords(driver);
		switch (Action) {
		case "getURL":
			Key.getURL(Data);
			break;
		case "type":
			Key.type(Locator, Data);
			break;
		case "getSceenShot":
			Key.getSceenShot(Data);
			break;
		default:
			System.out.println("Invalid Key");
		}
	}

	@DataProvider
	public Object[][] dp() {
		ExcelReader excel = new ExcelReader("C:\\Users\\vshadmin\\Desktop\\data.xls");
		Object[][] data = excel.getSheetData("Sheet2", 4, 2);
		return data;
	}

}
