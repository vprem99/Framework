package in.lti.day2;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class Blazrdemo {

	public static void main(String[] args) {

		System.setProperty("webdriver.chrome.driver", "C:\\Users\\AM101_PC1\\Downloads\\chromedriver_win32\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.get("http://blazedemo.com/");
		
		Select  selectFrom=new Select(driver.findElement(By.name("fromPort")));
		//selectFrom.selectByVisibleText("Portland");
		//selectFrom.selectByIndex(6);
		selectFrom.selectByValue("Portland");
		
		Select  selectTo=new Select(driver.findElement(By.name("toPort")));
		selectTo.selectByVisibleText("London");
		driver.findElement(By.cssSelector("input[value='Find Flights']")).click();
		
		
		//driver.findElement(By.cssSelector("input[value='Choose This Flight']")).click();
		
		List<WebElement> ls=driver.findElements
				(By.cssSelector("input[value='Choose This Flight']"));
		ls.get(2).click();
		
		driver.findElement(By.id("rememberMe")).click();
	}
}
