package in.lti.day2;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;

public class Humsafar {

	public static void main(String[] args) 
	{
		System.setProperty("webdriver.gecko.driver", ".\\Drivers\\geckodriver.exe");
		WebDriver driver=new FirefoxDriver();
		Actions a=new Actions(driver);
		driver.get("https://indiarailinfo.com/");
		a.moveToElement(driver.findElement(By.linkText("Trains"))).perform();
		a.click(driver.findElement
				(By.cssSelector("td[pref='/trains/humsafar-express/humsafar']")))
				.perform();
	
		WebElement search=driver.findElement(By.name("q"));
		Action ac=new Actions(driver).keyDown(Keys.SHIFT)
					.sendKeys(search, "lti")
					.doubleClick(search)
					.contextClick(search)
					.build();
		ac.perform();
		
		
		
		
	/*Difference Between Actions & Action
	 * 1. Actions is Class & Action is Interface
	 * 2. Use Actions for immediate Performance
	 * 		& Use Action for composite actions & Performance
	 * 
	 * */	
		
		
		
		
		
		

	}

}
