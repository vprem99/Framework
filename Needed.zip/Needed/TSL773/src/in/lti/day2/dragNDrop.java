package in.lti.day2;

import java.io.File;
import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.io.FileHandler;

public class dragNDrop 
{

	public static void main(String[] args) throws IOException {
		System.setProperty("webdriver.chrome.driver", ".\\Drivers\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		Actions a=new Actions(driver);
		driver.get("https://jqueryui.com/droppable/");
		driver.switchTo().frame(0); // To focus on Iframe
		WebElement from=driver.findElement(By.id("draggable"));
		WebElement to=driver.findElement(By.id("droppable"));
	
		a.dragAndDrop(from, to).perform();
		
		/*FirefoxDriver  WebDriver
		TakesScreenshot
		*/
		
		TakesScreenshot screen=(TakesScreenshot)driver;
		File src=screen.getScreenshotAs(OutputType.FILE);
		FileHandler.copy(src, new File(".\\screen1.png"));
		
		
		/*
		 * 
		 * In Year 2004,
QTP	> Mecury Intractive


Jason Huggins
JavaScript having Capabilty of Record & playBack

JavaScriptTestExecutor   > Selenium

-------------------------------
*/		
	}
}
