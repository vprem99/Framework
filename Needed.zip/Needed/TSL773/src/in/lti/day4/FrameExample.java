package in.lti.day4;

import java.util.Set;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class FrameExample {

	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver", ".\\Drivers\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("http://192.168.100.121:9090/frameExample.html");
		
		driver.switchTo().frame("selenium");// ID or Name as String Argument
		driver.findElement(By.linkText("Selenium blog")).click();
		driver.switchTo().defaultContent(); // Comes back from Frame 

		driver.switchTo().frame("blaze");// ID or Name as String Argument
		new Select(driver.findElement(By.name("fromPort"))).selectByVisibleText("Portland");
		driver.switchTo().defaultContent(); // Comes back from Frame 

		//driver.switchTo().frame(2);
		driver.switchTo().frame(driver.findElement(By.cssSelector("iframe[src='http://www.sololearn.com']")));
		driver.findElement(By.linkText("Start Learning Now")).click();
		
		driver.switchTo().defaultContent(); // Comes back from Frame 

		String Parent=driver.getWindowHandle(); 
		// For Getting Parent Window/Tab ID
				
		driver.findElement(By.linkText("AlertExample")).click();
		Set<String> AllWin=driver.getWindowHandles();
		for(String T:AllWin)
		{
			if(!(T.equals(Parent)))
			{
				driver.switchTo().window(T);
				System.out.println("You are On "+driver.getTitle());
				driver.findElement(By.cssSelector("button[onclick='myFunction1()']")).click();;
				Alert A=driver.switchTo().alert();
				String txt=A.getText();
				A.accept();
/*				A.accept();// Pressing on OK
				A.dismiss();// Pressing on Cancel
				A.sendKeys("LTI");
*/				System.out.println(txt);
				Thread.sleep(5000);	
				driver.close();//For closing current focused Tab/Window
			}
		}
		driver.switchTo().window(Parent);
		
	}
}