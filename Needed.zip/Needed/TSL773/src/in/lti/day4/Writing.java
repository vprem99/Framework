package in.lti.day4;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;

import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

public class Writing 
{

	public static void main(String[] args)throws Exception
	{
		FileInputStream IP=new FileInputStream("C:\\Users\\vshadmin\\Desktop\\data.xls");
		HSSFWorkbook wb=new HSSFWorkbook(IP);
		HSSFSheet sheet=wb.getSheet("Sheet1");
		
		//sheet.getRow(4).getCell(1).setCellValue("LTI");
		
		//sheet.getRow(4).createCell(2).setCellValue("LTI");
		sheet.createRow(5).createCell(2).setCellValue("LTI");
		sheet.createRow(3).createCell(2).setCellValue("LTI");

	
		//FileOutputStream OP=new FileOutputStream("C:\\Users\\vshadmin\\Desktop\\data2.xls");
		wb.write(new FileOutputStream("C:\\Users\\vshadmin\\Desktop\\data2.xls"));
		
		

	}

}
