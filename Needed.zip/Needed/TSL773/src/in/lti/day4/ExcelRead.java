package in.lti.day4;

import java.io.FileInputStream;
import java.io.FileOutputStream;

import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class ExcelRead {

	public static void main(String[] args) throws Exception
	{

		FileInputStream IP=new FileInputStream("C:\\Users\\vshadmin\\Desktop\\data.xls");
		HSSFWorkbook wb=new HSSFWorkbook(IP);
		HSSFSheet sheet=wb.getSheet("Sheet1");
		
		int rowNum=sheet.getLastRowNum();
		int colNum=	sheet.getRow(0).getLastCellNum();
			
		System.out.println("Total Rows are "+rowNum);
		System.out.println("Total col are "+colNum);
		
		
		
		
		
		System.setProperty("webdriver.chrome.driver", ".\\Drivers\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("http://127.0.0.1:8080/htmldb/f?p=4550:11:266957866376161029::NO:::");
		for(int i=1;i<=rowNum;i++)  // Rows
		{
			for(int j=0;j<colNum;j++)
			{
				String data=sheet.getRow(i).getCell(j).toString();
				System.out.print(data+" ");
				if(j==0)
					driver.findElement(By.name("p_t01")).sendKeys(data);
				else if(j==1)
					driver.findElement(By.name("p_t02")).sendKeys(data);
			}
			driver.findElement(By.cssSelector("input[type='BUTTON']")).click();
			if(driver.getTitle().equals("Oracle"))
			{
				driver.findElement(By.linkText("Logout")).click();
				System.out.println("Login Done");
				driver.findElement(By.linkText("Login")).click();
				sheet.getRow(i).createCell(2).setCellValue("PASS");
			}
			else
			{
				System.out.println("Login Fail");
				sheet.getRow(i).createCell(2).setCellValue("Failed");
			}
		}
		wb.write(new FileOutputStream("C:\\Users\\vshadmin\\Desktop\\data2.xls"));

	}
}