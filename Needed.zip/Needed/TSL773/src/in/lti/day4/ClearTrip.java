package in.lti.day4;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class ClearTrip 
{
	public static void main(String[] args) 
	{
		System.setProperty("webdriver.chrome.driver", ".\\Drivers\\chromedriver.exe");

		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://www.cleartrip.com/");
		driver.findElement(By.id("userAccountLink")).click();
		driver.findElement(By.id("SignIn")).click();
		driver.switchTo().frame("modal_window");
		driver.findElement(By.id("email")).sendKeys("mpremchand99@gmail.com");
		
	}
}