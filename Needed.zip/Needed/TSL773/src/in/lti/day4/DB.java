package in.lti.day4;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class DB 
{

	public static void main(String[] args) throws Exception
	{
		 DriverManager.registerDriver(new oracle.jdbc.OracleDriver());
		 Connection C=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "hr", "hr");
		 ResultSet R=  C.createStatement().executeQuery("Select * from login");
		System.setProperty("webdriver.chrome.driver", ".\\Drivers\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("http://127.0.0.1:8080/htmldb/f?p=4550:11:266957866376161029::NO:::");
	
		while(R.next()==true)
		{
			String UN=R.getString(1);
			String PWD=R.getString(2);
			driver.findElement(By.name("p_t01")).sendKeys(UN);
			driver.findElement(By.name("p_t02")).sendKeys(PWD);
			driver.findElement(By.cssSelector("input[type='BUTTON']")).click();
			if(driver.getTitle().equals("Oracle"))
			{
				driver.findElement(By.linkText("Logout")).click();
				System.out.println("Login Done");
				driver.findElement(By.linkText("Login")).click();
			}
			else
			{
				System.out.println("Login Fail");
			}
		} 
	}
}