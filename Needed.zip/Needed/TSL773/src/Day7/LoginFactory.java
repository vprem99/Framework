package Day7;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LoginFactory {

	LoginFactory(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}

	private WebElement txtUsername;

	private WebElement txtPassword;

	private	WebElement btnLogin;
	
	
	public void LoginProcess(String UN,String PWD)
	{
		txtUsername.sendKeys(UN);
		txtPassword.sendKeys(PWD);
		btnLogin.click();
	}
	
	
}
