package Day7;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class HomeFactory {
	HomeFactory(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}
	
	
	
	@FindBy(linkText ="Welcome Admin")
	WebElement E_Welcome;

	@FindBy(linkText ="Logout")
	WebElement E_Logout;
	
	
	public void LogOutProcess()
	{
		E_Welcome.click();
		E_Logout.click();
		
		
	}

}
