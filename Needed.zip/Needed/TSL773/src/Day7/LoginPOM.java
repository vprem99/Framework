package Day7;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class LoginPOM 
{
	WebDriver driver;
	LoginPOM(WebDriver driver)
	{
		this.driver=driver;
	}
	
	By E_UN=By.id("txtUsername");
	By E_PWD=By.id("txtPassword");
	By E_LOGIN=By.id("btnLogin");
	
	//https://opensource-demo.orangehrmlive.com/index.php/auth/login
	public void LoginProcess(String UN,String PWD)
	{
		driver.findElement(E_UN).sendKeys(UN);
		driver.findElement(E_PWD).sendKeys(PWD);
		driver.findElement(E_LOGIN).click();
	}

}
