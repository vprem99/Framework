package Day7;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import util.Base;

public class AllLinks extends Base{
  @Test
  public void linkTest() 
  {
	  driver.get("http://newtours.demoaut.com/");
	  List<WebElement> ls= driver.findElements(By.xpath("//a"));
	  
	  for(int i=0;i<ls.size();i++)
	  {
		  ls= driver.findElements(By.xpath("//a"));
		  System.out.println(ls.get(i).getText());
		  
		  ls.get(i).click();
		  driver.navigate().back();
		  
		  
		  
	  }
	  
	  
	  
	  
	  
	  
	  
	  
  }
}
