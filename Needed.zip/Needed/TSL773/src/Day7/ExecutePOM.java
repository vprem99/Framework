package Day7;

import java.io.FileInputStream;
import java.util.Properties;

import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.Test;


import util.Base;

public class ExecutePOM extends Base {
 @Test(priority=1,groups={"POM"})
  public void LoginExecutePOM() 
  {
	  driver.get("https://opensource-demo.orangehrmlive.com");
	  LoginPOM LG=new LoginPOM(driver);
	  LG.LoginProcess("admin", "admin1236");
	  Assert.assertEquals(driver.findElement(By.id("welcome")).isDisplayed(),true);
  }

  @Test(priority=2,groups={"POM"},dependsOnMethods= {"LoginExecutePOM"})
  public void LogoutExecutePOM() 
  {
	  HomePOM HP=new HomePOM(driver);
	  HP.LogOutProcess();
  }

  
  @Test(priority=3,groups={"FACTORY"})
  public void LoginExcuteFactory() 
  {
	  driver.get("https://opensource-demo.orangehrmlive.com");
	  LoginFactory LG=new LoginFactory(driver);
	  LG.LoginProcess("admin", "admin123");
	  Assert.assertEquals(driver.findElement(By.id("welcome")).isDisplayed(),true);

  }

  @Test(priority=4,groups={"FACTORY"})
  public void LogoutExecuteFactory() 
  {
	  HomeFactory HP=new HomeFactory(driver);
	  HP.LogOutProcess();
  }

  
  
  /*@Test(priority=2)
  public void AllLinks() 
  {
	  driver.get("http://newtours.demoaut.com");
	  AllLinksFactory HP=new AllLinksFactory(driver);
	  HP.clickOnLinks();
  }*/
}
