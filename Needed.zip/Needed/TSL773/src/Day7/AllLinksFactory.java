package Day7;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class AllLinksFactory {
	WebDriver driver;

	AllLinksFactory(WebDriver driver) {
		PageFactory.initElements(driver, this);
		this.driver = driver;
	}

	@FindBy(tagName = "a")
	@CacheLookup
	List<WebElement> ls;

	public void clickOnLinks() {

		for (int i = 0; i < ls.size(); i++) {
			ls.get(i).click();
			driver.navigate().back();
		}

	}

}
