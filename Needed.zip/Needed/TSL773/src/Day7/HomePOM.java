package Day7;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class HomePOM extends Base
{
	
/*	Vehicle
	
	IS_A
	
	Car 	Bike 	 Bus
*/	
	WebDriver driver;
	HomePOM(WebDriver driver)
	{
		this.driver=driver;
	}
	
	By E_welcome=By.linkText("Welcome Admin");
	By E_Logout=By.linkText("Logout");
	
	public void LogOutProcess()
	{
		driver.findElement(E_welcome);
		
		WebDriverWait wt=new WebDriverWait(driver, 20);
		wt.until(ExpectedConditions.visibilityOfElementLocated(E_Logout));

		driver.findElement(E_Logout).click();
		
		
	}
	
	
	

}
