package Day7;

import org.testng.annotations.Test;

public class GroupExample {
	@Test(groups = { "smoke", "regression" })
	public void f1() {
		System.out.println("In Smoke & regression Test");
	}

	@Test(groups = { "smoke" })
	public void f2() {
		System.out.println("In Smoke Test");
	}

	@Test(groups = { "sanity", "regression" })
	public void f3() {
		System.out.println("In sanity & regression Test");
	}

	@Test(groups = { "sanity" })
	public void f4() {
		System.out.println("In sanity Test");
	}
}
