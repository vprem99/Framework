package Day7;

import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.URL;
import java.net.URLConnection;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

import util.Base;

public class LinkImages extends Base {
	@Test
	public void f() throws Exception 
	{
		driver.get(prop.getProperty("url", "http://google.com"));
		List<WebElement> link = driver.findElements(By.tagName("a"));
		System.out.println("====================Link Check Started====");
		for (WebElement E : link) {
			String href = E.getAttribute("href");
			System.out.println(href);
			LinkCheck(href);
		}

		List<WebElement> Img = driver.findElements(By.tagName("img"));
		System.out.println("====================Img Check Started====");
		for (WebElement E : Img) {
			String src = E.getAttribute("src");
			System.out.println(src);
			LinkCheck(src);
		}
		/*Select select=new Select(driver.findElement(By.name("cars")));
		select.isMultiple();
		driver.findElement(By.xpath("//*[text()='Homepage']/ancestor::li/following-sibling::li[3]")).click();*/
	}

	public void LinkCheck(String href_src) {
		try {
			URL url = new URL(href_src);
			Proxy webproxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress("192.168.100.1", 8081));
			URLConnection UC = url.openConnection(webproxy);
			HttpURLConnection HUC = (HttpURLConnection) UC;
			HUC.connect();
			if (HUC.getResponseCode() == 200) {
				System.out.println(href_src + " is Working Fine");
			} else {
				System.out.println(href_src + " having response code as " + HUC.getResponseCode());
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}