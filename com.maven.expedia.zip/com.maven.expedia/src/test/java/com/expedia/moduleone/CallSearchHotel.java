package com.expedia.moduleone;

import java.util.concurrent.TimeUnit;

import org.testng.annotations.Test;

import com.expedia.utils.Base;

import com.expedia.moduleone.SearchHotelTest;

public class CallSearchHotel extends Base{


 @Test(priority = 1)
  public void Hotel()   {
	  
	  driver.get(prop.getProperty("url"));
	  SearchHotelTest search_hotel=new SearchHotelTest(driver);
	  search_hotel.loopSearch();
	  search_hotel.search();
	  HotelEnd hotel=new HotelEnd(driver);
	  hotel.endClick();
  }

}
