package com.expedia.moduleone;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class HotelEnd {


	private WebDriver driver;
	private WebDriverWait wait;
	
	@FindBy(xpath = "//body/div[@id='app']/div/div[@class='app-layer-base--active']/div[@class='page-container search-results']/div[@class='uitk-flex two-column-body']/div[@class='uitk-flex-grow-1 uitk-cell l-x-padding-six xl-x-padding-six']/main[@class='main-region search-results__main all-x-padding-two']/div[@class='search-results-listing all-y-padding-three']/div[@class='uitk-grid']/div[@class='uitk-cell all-cell-3-4 all-x-gutter-six']/section[@class='results']/ol[@class='uitk-grid all-x-gutter-three all-y-gutter-three results-list']/li[1]/div[1]/div[1]/a[1]")
	private WebElement FirstHotelLink;
	
	@FindBy(xpath = "//*[text()='Reserve']")
	private WebElement ReserveClick;
	
	@FindBy(xpath = "//input[@placeholder='First and last name']")
	private WebElement EnterName;	
	
	@FindBy(xpath = "//input[@placeholder='So the property can reach you']")
	private WebElement EnterPhone;
	
	
	
	@FindBy(xpath = "//input[@id='creditCardInput']")
	private WebElement cardNo;
	
	//@FindBy(xpath = "//label[@class='text invalid']//input[@name='email']")
	//private WebElement EmailID;
	
	@FindBy(id="complete-booking")
	private WebElement payment_submit;
	
	
	
public HotelEnd(WebDriver driver) {
		
		this.driver = driver;
		PageFactory.initElements(driver, this);
		wait = new WebDriverWait(driver, 10);
	}
	
public void endClick()
{
	FirstHotelLink.click();
	wait.until(ExpectedConditions.numberOfWindowsToBe(2));
	driver.switchTo().window(driver.getWindowHandles().toArray()[1].toString());
	ReserveClick.click();
	
	EnterName.sendKeys("Isha Wanjari");
	EnterPhone.sendKeys("8551027242");
	cardNo.sendKeys("12233444333");
	//EmailID.sendKeys("IshaWanjari25@gmail.com");
	payment_submit.click();
}
}

