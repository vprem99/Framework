package com.expedia.moduleone;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;


public class SearchHotelTest  {
	
	private WebDriver driver;
	private WebDriverWait wait;
	
	
	@FindBy(xpath = "//*[@id=\"hotel-destination-hp-hotel\"]")
	private WebElement City;
	@FindBy(xpath = "//div[@class='tabs-container col']//div[2]//table[1]//tbody[1]//tr[5]//td[5]//button[1]")
	private WebElement CheckIn_date_select;
	@FindBy(xpath = "//button[@class='datepicker-cal-date'][contains(text(),'30')]")
	private WebElement CheckOut_date_select;
	@FindBy(xpath = "/html/body/meso-native-marquee/section/div/div/div[1]/section/div[1]/div[2]/div[2]/section[2]/form/div[11]/label/button")
	private WebElement search_button;
	@FindBy(xpath = "//div[@class='global-nav-header-links__item uitk-cell all-cell-shrink all-r-padding-two all-y-padding-three active']//a[contains(text(),'Hotels')]")
	private WebElement Hotel_again;
	@FindBy(xpath = "//a[@id='primary-header-home']")
	private WebElement Home_again;
	
	@FindBy(id = "hotel-checkin-hp-hotel")
	private WebElement date_checkIn_icon;
	@FindBy(id = "hotel-checkout-hp-hotel")
	private WebElement date_checkOut_icon;
	

  public SearchHotelTest(WebDriver driver) {
		
		this.driver = driver;
		PageFactory.initElements(driver, this);
		wait = new WebDriverWait(driver, 10);
	}
 public void loopSearch() {
	 
	ExcelReader ex=new ExcelReader("D:\\City_Hotel.xlsx");
	
	String City_hotel[][]=ex.getAllData("Sheet1",3,2);
    for(int x=0;x<City_hotel.length;x++) {
	 	
	 	City.sendKeys(City_hotel[x][0].toString());
	 	date_checkIn_icon.click();
	 	//System.out.println(City_hotel[x][1]);
	 	
	 	date_checkIn_icon.sendKeys((City_hotel[x][1].toString()));
	 	//wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[@class='datepicker-cal-date'][contains(text(),'30')]")));
	 	date_checkOut_icon.click();
	 	//System.out.println(City_hotel[x][2]);
	 	date_checkOut_icon.sendKeys(City_hotel[x][2].toString());
		//wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//form[@id='gcw-flights-form-hp-flight']//button[@class='btn-primary btn-action gcw-submit']")));
	 	search_button.click();
	 	Hotel_again.click();
		//wt.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id=\\\"primary-header-home\\\"]")));
		  Home_again.click();
		//wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[@id='primary-header-home']")));
		  // to clear the destination text field
		  City.clear();
		  date_checkIn_icon.clear();
		  date_checkOut_icon.clear();
		  
		  
		  }
 } 
 
 public void search() {
	 	City.sendKeys("Goa");
	 	search_button.click();
 }  
 
}
