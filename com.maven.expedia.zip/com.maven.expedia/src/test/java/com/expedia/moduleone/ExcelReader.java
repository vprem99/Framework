package com.expedia.moduleone;

import java.io.FileInputStream;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelReader {
	    Workbook book;
	    ExcelReader (String  FileNameWithLocation)
	{	
	 try 
	{
	      if(FileNameWithLocation.endsWith("xlsx"))
	      {
		  book=new XSSFWorkbook(new FileInputStream(FileNameWithLocation));
		}
		else if(FileNameWithLocation.endsWith("xls")) {
			book = new HSSFWorkbook(new FileInputStream(FileNameWithLocation));
		}
	}
	catch(Exception E)
	 {
		System.out.println("Error With File Colllection"+E.getMessage());
	 }
	}
	public String getCellData(String sheet1,int row,int col) {
		return book.getSheet(sheet1).getRow(row).getCell(col).toString();
		
	}
    public int getRowNum(String sheet1) {
    	int rows = book.getSheet(sheet1).getLastRowNum();
    	return rows;
    }
    public int getColNum(String sheet1) {
    	int col = book.getSheet(sheet1).getRow(0).getLastCellNum();
    	return col-1;
    }
    
    public String[][] getAllData(String sheet1,int row,int col){
    	String data[][] = new String[row][col+1];
    	for(int i=1;i<=row;i++)
    	{
    		for(int j=0;j<=col;j++)
    		{
    			data[i-1][j] = getCellData(sheet1,i,j);
    		}
    	}
    	return data;
    }
    
    
}

