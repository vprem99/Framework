package com.expedia.modulethree;

import java.io.FileReader;
import java.util.List;

import org.openqa.selenium.By;
import org.testng.annotations.Test;

import com.expedia.utils.Base;

import au.com.bytecode.opencsv.CSVReader;

public class LoginLogoutInvalidData extends Base {
	@Test
	public void loginLogout() throws Exception {
		driver.get(prop.getProperty("url"));
		CSVReader cs = new CSVReader(new FileReader("D:\\com.maven.expedia\\InvalidData.csv"));
		List<String[]> alldata = cs.readAll();
		for (int i = 0; i < alldata.size(); i++) {
			String[] row = alldata.get(i);
			driver.findElement(By.id("header-account-menu")).click();
			driver.findElement(By.id("account-signin")).click();

			driver.findElement(By.id("gss-signin-email")).sendKeys(alldata.get(i)[0]);// sending all the username
			driver.findElement(By.id("gss-signin-password")).sendKeys(alldata.get(i)[1]);
			driver.findElement(By.id("gss-signin-submit")).click();

			try {
				driver.findElement(By.id("header-account-menu-signed-in")).click();
				driver.findElement(By.id("account-signout")).click();

			} catch (Exception E) {
				System.out.println("LOGIN failed");
			}
		}
	}
}
