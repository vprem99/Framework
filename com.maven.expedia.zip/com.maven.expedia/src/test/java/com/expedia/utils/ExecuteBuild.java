package com.expedia.utils;

import org.testng.annotations.Test;

public class ExecuteBuild extends Base {
	@Test
	public void f() {
		SearchBuild search = new SearchBuild(driver);
		search
			.goToFlight()
			.setImplicitwait(30)
			.verifyEqual("")
			.setFrom("Mumbai")
			.setTo("Delhi")
			.selectDate().verifyEqual("").setImplicitwait(20);
	}
}
