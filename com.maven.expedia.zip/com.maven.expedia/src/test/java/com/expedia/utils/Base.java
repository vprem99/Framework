package com.expedia.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.io.FileHandler;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

import atu.testrecorder.ATUTestRecorder;
import atu.testrecorder.exceptions.ATUTestRecorderException;

public class Base {
	public WebDriver driver;
	ATUTestRecorder recorder;
	public static ExtentReports extent;
	public static ExtentTest test1_log;
	public static String finalPath;
	public Properties prop;

	@BeforeSuite
	public void beforeSuite() {
		// login
		extent = new ExtentReports();
		ExtentHtmlReporter html = new ExtentHtmlReporter(".\\lReport.html");
		extent.attachReporter(html);
		ExtentHtmlReporter html1 = new ExtentHtmlReporter(".\\multicityReport.html");
		extent.attachReporter(html1);
		prop = new Properties();
		try {
			prop.load(new FileInputStream(".\\Constant.property"));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@BeforeTest
	public void beforeTest() throws Exception {
		System.setProperty("webdriver.gecko.driver", "D:\\1SEL\\geckodriver.exe");
		driver = new FirefoxDriver();

		DateFormat dateFormat = new SimpleDateFormat("yy-MM-dd HH-mm-ss");
		Date date = new Date();
		// Created object of ATUTestRecorder
		// Provide path to store videos and file name format.
		// String path1="D:\\ScriptVideos\\","TestVideo-"+dateFormat.format(date)";

		String P = "TestVideo-" + dateFormat.format(date) + ".mov";
		String path = "D:\\ScriptVideos\\";
		finalPath = path + P;
		recorder = new ATUTestRecorder(path, P, false);

		// To start video recording.
		recorder.start();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
	}

	@AfterMethod
	public void afterMethod(ITestResult R) throws IOException {
		Date d = new Date();
		String newDate = d.toString().replace(" ", "_").replace(":", "_");
			if (R.getStatus() == ITestResult.FAILURE) {
			test1_log.log(Status.FAIL, "TEST CASE FAILED");
			try {
				File src = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
				String path = ".\\test-output\\" + R.getName() + newDate + ".png";
				FileHandler.copy(src, new File(path));
				test1_log.addScreenCaptureFromPath(path);
				test1_log.info("Screenshot successfully taken and added");
			} catch (Exception e) {
				test1_log.info("Failed to take screenshot");
			}
		} else {
			test1_log.log(Status.PASS, "TEST CASE PASSED");
		}

		test1_log.info("Path of Video " + finalPath);

	}

	@AfterTest
	public void afterTest() throws ATUTestRecorderException {
		// driver.quit();
		// To stop video recording.

		recorder.stop();

	}

	@AfterSuite
	public void afterSuite() {
		extent.flush();
	}

}