package com.expedia.utils;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

public class SearchBuild {
	WebDriver driver;

	public SearchBuild(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);

	}

	@FindBy(xpath = "//button[@id='tab-flight-tab-hp']//span[@class='uitk-icon uitk-icon-flights']")
	private WebElement flighticon;
	@FindBy(xpath = "//label[@id='flight-type-one-way-label-hp-flight']")
	private WebElement chooseway;
	@FindBy(id = "flight-origin-hp-flight")
	private WebElement source;
	@FindBy(id = "flight-destination-hp-flight")
	private WebElement destination;
	@FindBy(id = "flight-departing-single-hp-flight")
	private WebElement checkindate;
	@FindBy(xpath = "//div[@class='tabs-container col']//div[2]//table[1]//tbody[1]//tr[4]//td[7]//button[1]")
	private WebElement selectcheckindate;

	public SearchBuild goToFlight() {
		flighticon.click();
		return this;
	}

	public SearchBuild setFrom(String from) {
		chooseway.click();
		source.sendKeys(from);
		return this;
	}

	public SearchBuild setTo(String to) {
		destination.sendKeys(to);
		return this;
	}

	public SearchBuild selectDate() {
		checkindate.click();
		selectcheckindate.click();
		checkindate.sendKeys(Keys.ENTER);
		return this;
	}

	public SearchBuild setImplicitwait(int time) {
		this.driver.manage().timeouts().implicitlyWait(time, TimeUnit.SECONDS);
		return this;
	}

	public SearchBuild verifyEqual(String expected) {
		Assert.assertEquals(this.driver, expected);
		return this;
	}

}
