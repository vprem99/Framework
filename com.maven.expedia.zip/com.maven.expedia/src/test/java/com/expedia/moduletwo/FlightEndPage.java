package com.expedia.moduletwo;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.expedia.utils.Base;

public class FlightEndPage extends Base {
	private WebDriver driver;
	private WebDriverWait wait;
	//=new WebDriverWait(driver, 30);
	
	
	@FindBy(xpath="/html/body/div[2]/div[8]/section/div/div[10]/ul/li[1]/div[1]/div[1]/div[2]/div/div[2]/button")
	private WebElement select_flight;  
	
	By pop_up=By.xpath("//*[@id=\\\"forcedChoiceNoThanks\\\"]");
	
	//@FindBy(xpath="//*[@id=\"forcedChoiceNoThanks\"]")
	//private WebElement pop_up1;
	
	@FindBy(id="bookButton")
	private WebElement book_button;
	
	
	@FindBy(xpath="//select[@id='title[0]']")
	private WebElement gender_select;
	
	@FindBy(id="lastname[0]")
	private WebElement lastname;
	
	@FindBy(id="firstname[0]")
	private WebElement firstname;
	
	@FindBy(id="phone-number[0]")
	private WebElement phoneNo;
	
	@FindBy(id="gender_male[0]")
	private WebElement male;

	@FindBy(id="complete-booking")
	private WebElement book;
	
	public FlightEndPage(WebDriver driver) {
			
			this.driver = driver;
			PageFactory.initElements(driver, this);
			wait = new WebDriverWait(driver, 10);
		}

	  public void bookFlight() throws InterruptedException  {
		 // wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//li[@id='flight-module-2019-12-31t06:00:00+05:30-coach-bom-del-g8-329_']//button[@class='btn-secondary btn-action t-select-btn']")));
		  test1_log = extent.createTest("BookFlight");
		  test1_log.info("click on flight icon");
		  select_flight.click();
		 wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id=\"forcedChoiceNoThanks\"]")));
		 
		 test1_log.info("click on no thanks");
		 driver.findElement(By.xpath("//*[@id=\"forcedChoiceNoThanks\"]")).click(); 
		 // pop_up1.click();
		 Thread.sleep(3000);
		  wait.until(ExpectedConditions.numberOfWindowsToBe(2));
		  test1_log.info("switch tab");
		  driver.switchTo().window(driver.getWindowHandles().toArray()[1].toString());
		  new WebDriverWait(driver, 20).until(ExpectedConditions.visibilityOf(book_button));
		  test1_log.info("click on book button");
		  book_button.click();
		  
		  try {
				new WebDriverWait(driver, 30).until(ExpectedConditions.visibilityOfElementLocated(By.id("modalCloseButton")));
				driver.findElement(By.id("modalCloseButton")).click();
				Thread.sleep(5000);
			
			} catch (Exception E) {
				System.out.println("Pop up not came"+E.getMessage());
				E.printStackTrace();
			}
		  test1_log.info("select title");
		  Select gender_title = new Select(gender_select);
		  gender_title.selectByVisibleText("Mr.");
		  
		  test1_log.info("Enter firstname and lastname");
		  lastname.sendKeys("ABC");
		  firstname.sendKeys("ABC");
		  
		  test1_log.info("Enter phone number");
		  phoneNo.sendKeys("9999999999");
		  
		  test1_log.info("Select gender");
		  male.click();
		  
		  test1_log.info("Click on book button");
		  book.click();
		  
	  }
}
