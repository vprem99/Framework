package com.expedia.moduletwo;



	import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import com.expedia.utils.Base;


	public class FlightMultiCity extends Base {
		@Test
		public void flightMultiCity() throws Exception {
			WebDriverWait wt = new WebDriverWait(driver, 500);
			Actions action = new Actions(driver);
			driver.get(prop.getProperty("url"));
			test1_log = extent.createTest("FlightMultiCity");
			DriverManager.registerDriver(new oracle.jdbc.OracleDriver());
			Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "aniket","aniket123");
			ResultSet R = con.createStatement().executeQuery("select * from FlightMultiDetails");
			while (R.next() == true) { 

				// flights icon
				  test1_log.info("clicking on flight icon");
				driver.findElement(By.id("tab-flight-tab-hp")).click(); 
		
				
				// choose way
				test1_log.info("clicking on choose way");
				driver.findElement(By.id("flight-type-multi-dest-label-hp-flight")).click();

				// 1st
				test1_log.info("Entering source city");
				driver.findElement(By.id("flight-origin-hp-flight")).sendKeys(R.getString("flight1_from"));
				Thread.sleep(5000);
				driver.findElement(By.id("flight-origin-hp-flight")).sendKeys(Keys.ENTER);

				test1_log.info("Entering destination city");
				driver.findElement(By.id("flight-destination-hp-flight")).sendKeys(R.getString("flight1_to"));
				Thread.sleep(5000);
				driver.findElement(By.id("flight-destination-hp-flight")).sendKeys(Keys.ENTER);

				test1_log.info("Entering departure date");
				driver.findElement(By.id("flight-departing-single-hp-flight")).sendKeys(R.getString("dep_date1"));
				Thread.sleep(5000);
				driver.findElement(By.id("flight-departing-single-hp-flight")).sendKeys(Keys.ENTER);
				
				// 2nd
				test1_log.info("Entering second source city");
				driver.findElement(By.id("flight-2-origin-hp-flight")).sendKeys(R.getString("flight2_from"));
				Thread.sleep(5000);
				driver.findElement(By.id("flight-2-origin-hp-flight")).sendKeys(Keys.ENTER);

				test1_log.info("Entering second destination city");
				driver.findElement(By.id("flight-2-destination-hp-flight")).sendKeys(R.getString("flight2_to"));
				Thread.sleep(5000);
				driver.findElement(By.id("flight-2-destination-hp-flight")).sendKeys(Keys.ENTER);

				test1_log.info("Entering second departure date");
				driver.findElement(By.id("flight-2-departing-hp-flight")).sendKeys(R.getString("dep_date2"));
				Thread.sleep(5000);
				driver.findElement(By.id("flight-2-departing-hp-flight")).sendKeys(Keys.ENTER);
				
				
				// search button
				test1_log.info("Clicking on search button");
				driver.findElement(By.xpath(
						"//form[@id='gcw-flights-form-hp-flight']//button[@class='btn-primary btn-action gcw-submit']"))
						.click();
				Thread.sleep(5000);
				
				// select button
				test1_log.info("Clicking on flight select button");
				wt.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@data-test-id='select-button']")));
				driver.findElement(By.xpath("//*[@data-test-id='select-button']")).click();
				
				//switch to next tab
				test1_log.info("Switching to next tab");
				wt.until(ExpectedConditions.numberOfWindowsToBe(2));  
				driver.switchTo().window(driver.getWindowHandles().toArray()[1].toString());	

				// continue booking
				test1_log.info("Clicking on continue booking button");
				driver.findElement(By.xpath("//button[@id='bookButton']")).click();

				ResultSet Res = con.createStatement().executeQuery("select * from traveller_details");
				while (Res.next() == true) {
					// title
					test1_log.info("Selecting title");
					Select title = new Select(driver.findElement(By.id("title[0]")));
					title.selectByVisibleText(Res.getString("title"));

					// lastname
					test1_log.info("Entering lastname");
					driver.findElement(By.id("lastname[0]")).sendKeys(Res.getString("surename"));

					// firstname
					test1_log.info("Entering firstname");
					driver.findElement(By.id("firstname[0]")).sendKeys(Res.getString("firstname"));

					// phone
					test1_log.info("Entering phone number");
					driver.findElement(By.id("phone-number[0]")).sendKeys(Res.getString("phone_no"));

					// gender
					test1_log.info("Selecting gender");
					driver.findElement(By.id("gender_male[0]")).click();

					// month
					test1_log.info("Selecting month");
					Select month = new Select(driver.findElement(By.id("date_of_birth_month0")));
					month.selectByVisibleText(Res.getString("month"));

					// day
					test1_log.info("Selecting day");
					Select day = new Select(driver.findElement(By.id("date_of_birth_day[0]")));
					day.selectByVisibleText(Res.getString("day"));

					// year
					test1_log.info("Selecting year");
					Select year = new Select(driver.findElement(By.id("date_of_birth_year[0]")));
					year.selectByVisibleText(Res.getString("year"));
					
					//card number
					test1_log.info("Entering card number");
					driver.findElement(By.id("creditCardInput")).sendKeys(Res.getString("debitcard"));
					driver.findElement(By.id("creditCardInput")).sendKeys(Keys.ENTER);
				

				}
			}
		}

	}

	
	
	
	

