package com.expedia.moduletwo;

import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.Test;

import com.expedia.utils.Base;

public class CallSearchFlight extends Base {
  @Test
  public void Flight() throws Exception{
	  
		
		driver.get(prop.getProperty("url"));
		FlightFirstPage search_flight=new FlightFirstPage(driver);
		search_flight.loopFlight();
		search_flight.searchFlight();
		
		
		FlightEndPage book_flight=new FlightEndPage(driver);
		book_flight.bookFlight();
		  
	  }
}
