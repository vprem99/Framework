package com.expedia.moduletwo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.expedia.utils.Base;

public class FlightFirstPage extends Base {
	private WebDriver driver;
	private WebDriverWait wait;

	@FindBy(xpath = "//button[@id='tab-flight-tab-hp']//span[@class='uitk-icon uitk-icon-flights']")
	private WebElement flighticon;
	@FindBy(xpath = "//label[@id='flight-type-one-way-label-hp-flight']")
	private WebElement chooseway;
	@FindBy(id = "flight-origin-hp-flight")
	private WebElement source;
	@FindBy(id = "flight-destination-hp-flight")
	private WebElement destination;
	@FindBy(id = "flight-departing-single-hp-flight")
	private WebElement checkindate;
	@FindBy(xpath = "//div[@class='tabs-container col']//div[2]//table[1]//tbody[1]//tr[4]//td[7]//button[1]")
	private WebElement selectcheckindate;
	@FindBy(xpath = "//div[@class='menu-bar gcw-travel-selector-wrapper']//button[@class='trigger-utility menu-trigger btn-utility btn-secondary dropdown-toggle theme-standard pin-left menu-arrow gcw-component gcw-traveler-amount-select gcw-component-initialized']")
	private WebElement travelers;
	@FindBy(xpath = "//body[@class='wrap cf aoa-enabled']/meso-native-marquee/section[@id='WizardHero']/div[@id='hero-banner']/div[@class='hero-banner-gradient native-marquee']/div[@class='cols-row hero-banner-inner']/section[@id='wizardSection']/div[@class='hero-banner-box siteId-27 cf hideClassicDcol']/div[@id='wizard-tabs']/div[@class='tabs-container col']/section[@id='section-flight-tab-hp']/form[@id='gcw-flights-form-hp-flight']/fieldset[@class='room-data']/div[@class='cols-nested']/div[@class='ab25184-traveler-wrapper-flight available-for-flights gcw-clear-both']/div[@id='traveler-selector-hp-flight']/div[@class='menu-bar gcw-travel-selector-wrapper']/ul[@class='menu-bar-inner']/li[@class='open']/div[@class='menu sticky gcw-menu']/div[@class='menu-main']/div[@class='traveler-selector-sinlge-room-data traveler-selector-room-data']/div[@class='uitk-grid step-input-outside gcw-component gcw-component-step-input gcw-step-input gcw-component-initialized']/div[4]/button[1]")
	private WebElement adults;
	@FindBy(xpath = "//div[@class='traveler-selector-sinlge-room-data traveler-selector-room-data']//div[@class='children-wrapper']//button[@class='uitk-step-input-button uitk-step-input-plus']//*[@class='uitk-icon-svg uitk-step-input-icon']")
	private WebElement children;
	@FindBy(id = "flight-age-select-1-hp-flight")
	private WebElement childrenage;
	@FindBy(xpath = "//div[@class='traveler-selector-sinlge-room-data traveler-selector-room-data']//div[@class='infants-wrapper']//button[@class='uitk-step-input-button uitk-step-input-plus']")
	private WebElement infant;
	@FindBy(xpath = "//select[@class='gcw-storeable gcw-toggles-field-by-value gcw-child-age-select gcw-infant-age-1-sa']")
	private WebElement infantage;
	@FindBy(xpath = "//form[@id='gcw-flights-form-hp-flight']//button[@class='btn-primary btn-action gcw-submit']")
	private WebElement searchbutton;
	@FindBy(id = "primary-header-home")
	private WebElement home;
	@FindBy(xpath = "//body[@class='wrap cf aoa-enabled']/meso-native-marquee/section[@id='WizardHero']/div[@id='hero-banner']/div[@class='hero-banner-gradient native-marquee']/div[@class='cols-row hero-banner-inner']/section[@id='wizardSection']/div[@class='hero-banner-box siteId-27 cf hideClassicDcol']/div[@id='wizard-tabs']/div[@class='tabs-container col']/section[@id='section-flight-tab-hp']/form[@id='gcw-flights-form-hp-flight']/fieldset[@class='room-data']/div[@class='cols-nested']/div[@class='ab25184-traveler-wrapper-flight available-for-flights gcw-clear-both']/div[@id='traveler-selector-hp-flight']/div[@class='menu-bar gcw-travel-selector-wrapper']/ul[@class='menu-bar-inner']/li[@class='open']/div[@class='menu sticky gcw-menu']/div[@class='menu-main']/div[@class='traveler-selector-sinlge-room-data traveler-selector-room-data']/div[@class='uitk-grid step-input-outside gcw-component gcw-component-step-input gcw-step-input gcw-component-initialized']/div[@class='uitk-col all-col-shrink']/button[@class='uitk-step-input-button uitk-step-input-minus']/span[@class='uitk-icon']/*[1]")
	private WebElement adultMinus;
	@FindBy(xpath = "//div[@class='traveler-selector-sinlge-room-data traveler-selector-room-data']//div[@class='children-wrapper']//button[@class='uitk-step-input-button uitk-step-input-minus']//*[@class='uitk-icon-svg uitk-step-input-icon']")
	private WebElement childrenMinus;

	public FlightFirstPage(WebDriver driver) {

		this.driver = driver;
		PageFactory.initElements(driver, this);
		wait = new WebDriverWait(driver, 10);

	}

	public void searchFlight() throws InterruptedException {
		test1_log = extent.createTest("FlightOneWay");

		test1_log.info("clicking on flight icon");
		flighticon.click();

		test1_log.info("clicking on choose way");
		chooseway.click();

		test1_log.info("entering source city");
		source.sendKeys("Mumbai");
		// source.sendKeys(Keys.ENTER);

		test1_log.info("entering destination city");
		destination.sendKeys("Delhi");
		// destination.sendKeys(Keys.ENTER);

		test1_log.info("selecting date");
		checkindate.click();
		selectcheckindate.click();
		checkindate.sendKeys(Keys.ENTER);
       Thread.sleep(3000);
	}

	public void loopFlight() throws Exception {
		test1_log = extent.createTest("FlightDataDriven");
		DriverManager.registerDriver(new oracle.jdbc.OracleDriver());
		Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "aniket", "aniket123");
		ResultSet R = con.createStatement().executeQuery("select * from Flight_Details");
																																																																											int i = 0;
		while (R.next() == true) {
			test1_log.info("clicking on flight icon");
			flighticon.click();

			test1_log.info("clicking on choose way");
			chooseway.click();

			test1_log.info("entering source city");
			source.sendKeys(R.getString("flight_from"));

			test1_log.info("entering destination city");
			destination.sendKeys(R.getString("flight_to"));

			test1_log.info("selecting date");
			checkindate.click();

			checkindate.sendKeys(R.getString("dep_date"));

		   if (i == 0) {
			test1_log.info("selecting traveller details");
			travelers.click();
			adults.click();
			children.click();

			Select child_age = new Select(childrenage);
			child_age.selectByValue("10");
			infant.click();
			Select infants_age = new Select(infantage);
			infants_age.selectByValue("1");
													 
	              }

		    checkindate.sendKeys(Keys.ENTER);

			Thread.sleep(3000);
			 test1_log.info("clicking on home button");
			 home.click();

			 source.clear();
			 destination.clear();
			 checkindate.clear();
		    	i++;
		}

	}

}
