package CPSAT;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class question5 {
	WebDriver driver;
	@BeforeTest
	  public void beforeTest() {
		  System.setProperty("webdriver.chrome.driver", ".\\Drivers\\chromedriver.exe");
			driver = new ChromeDriver(new ChromeOptions().addArguments("--disable-notifications"));  
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.manage().window().maximize();
		 }
	  @AfterTest
	  public void afterTest() {
		  //driver.quit();
		  }
	  	
	  
  @Test
  public void f() {
	  driver.get("https://www.shoppersstop.com/");
		new Actions(driver).moveToElement(driver.findElement(By.linkText("MEN"))).perform();
		new Actions(driver).moveToElement(driver.findElement(By.linkText("Accessories"))).perform();
		
		List<WebElement> accs = driver.findElements(By.xpath("/html/body/main/nav/div[2]/div/ul/li[4]/div/div/ul/li[4]/div/ul/li[1]/div/ul/li"));
		for(int i=1;i<accs.size();i++) {
			System.out.println(accs.get(i).getText());
		}
  driver.findElement(By.linkText("All Stores")).click();
  
	List<WebElement> cities = driver.findElements(By.xpath("//*[@id=\"city-name\"]/option"));
	for(int i=0;i<cities.size();i++) {
		System.out.println(cities.get(i).getText());
	}
	
		
	String A=driver.findElement(By.id("city-name")).getText();
		Assert.assertTrue(A.contains("Mumbai"));
		System.out.println("There is a store in Mumbai");
		
		Assert.assertTrue(A.contains("Delhi"));
		System.out.println("There is a store in Delhi");
		
		Assert.assertTrue(A.contains("Goa"));
		System.out.println("There is a store in Goa");

		String title = driver.getTitle();
        String reverse = "";
        
        
        for(int i = title.length() - 1; i >= 0; i--)
        {
            reverse = reverse + title.charAt(i);
        }
		System.out.println(reverse);

	
	
  
  }
}
