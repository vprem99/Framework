package CPSAT;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class question2PageFactory {

	public question2PageFactory(WebDriver driver)
	{
		PageFactory.initElements(driver, this);
	}
	@FindBy(xpath="/html/frameset/frame[1]")
	WebElement E_TopFrame;

	@FindBy(xpath="/html/frameset/frame[1]")
	WebElement E_Frame1;
	
	@FindBy(xpath="/html/body")
	WebElement E_left;
	
	public void left() {
		System.out.println(E_left.getText());
	}

	@FindBy(xpath="/html/frameset/frame[2]")
	WebElement E_Frame2;
	
	@FindBy(xpath="//*[@id=\"content\"]")
	WebElement E_middle;
	
	public void middle() {
		System.out.println(E_middle.getText());
	}
	
	@FindBy(xpath="/html/frameset/frame[3]")
	WebElement E_Frame3;
	
	@FindBy(xpath="/html/body")
	WebElement E_right;
	
	public void right() {
		System.out.println(E_right.getText());
	}
	
		@FindBy(xpath="/html/frameset/frame[2]")
	WebElement E_Frame4;
	
	@FindBy(xpath="/html/body")
	WebElement E_bottom;
	
	public void bottom() {
		System.out.println(E_bottom.getText());
	}
	
}
