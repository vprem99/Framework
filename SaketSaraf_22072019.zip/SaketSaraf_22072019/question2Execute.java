package CPSAT;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.lti.day8.HomePageFactory;

public class question2Execute{
	WebDriver driver;
	@BeforeTest
	  public void beforeTest() {
		  System.setProperty("webdriver.gecko.driver", ".\\Drivers\\geckodriver.exe");
			driver = new FirefoxDriver();  
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.manage().window().maximize();
		 }
	  @AfterTest
	  public void afterTest() {
		  //driver.quit();
		  }
	  	
	  
  @Test
  public void q2() throws Exception{
	  question2PageFactory q2 = new question2PageFactory(driver);

	  driver.get("http://the-internet.herokuapp.com/nested_frames");
	  /*driver.switchTo().frame(driver.findElement(By.xpath("/html/frameset/frame[1]")));
	  driver.switchTo().frame(driver.findElement(By.xpath("/html/frameset/frame[1]")));
	  System.out.println(driver.findElement(By.xpath("/html/body")).getText());*/
	  driver.switchTo().frame(q2.E_TopFrame);
	  driver.switchTo().frame(q2.E_Frame1);
	  q2.left();
	  driver.switchTo().defaultContent();

	  driver.switchTo().frame(q2.E_TopFrame);
	  driver.switchTo().frame(q2.E_Frame2);
	  q2.middle();
	  driver.switchTo().defaultContent();
	  driver.switchTo().frame(q2.E_TopFrame);
	  driver.switchTo().frame(q2.E_Frame3);
	  q2.right();
	  driver.switchTo().defaultContent();
	  driver.switchTo().frame(q2.E_Frame4);
	  q2.bottom();
  }
}
