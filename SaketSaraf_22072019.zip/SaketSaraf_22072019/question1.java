package CPSAT;


import java.io.File;
import java.io.IOException;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.io.FileHandler;


public class question1 {
	static WebDriver driver;
	
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		System.setProperty("webdriver.gecko.driver", ".\\Drivers\\geckodriver.exe");
		driver = new FirefoxDriver();
		driver.manage().window().maximize();
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}
	  
  @Test
  public void q1(){
	  driver.get("https://code.makery.ch/library/dart-drag-and-drop/");
	  
	  JavascriptExecutor executor = (JavascriptExecutor) driver;
	  executor.executeScript("arguments[0].scrollIntoView();", driver.findElement(By.id("sortable")));
	  //Thread.sleep(3000);
	  driver.switchTo().frame(driver.findElement(By.xpath("/html/body/div/article/div/div/iframe[10]")));
	  Actions A = new Actions(driver);
	  WebElement src = driver.findElement(By.xpath("/html/body/div/div/div[1]/p"));
		WebElement dest = driver.findElement(By.xpath("/html/body/div/div/div[3]/p"));
		A.dragAndDrop(src, dest).perform();
		
		TakesScreenshot screen = (TakesScreenshot)driver;
		File SRC = screen.getScreenshotAs(OutputType.FILE);
		
		 try {
			FileHandler.copy(SRC, new File(".\\question1.png"));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	  
  }
}
