package CPSAT;

import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class question4 {
	WebDriver driver;
	@BeforeTest
	  public void beforeTest() {
		  System.setProperty("webdriver.gecko.driver", ".\\Drivers\\geckodriver.exe");
			driver = new FirefoxDriver();  
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.manage().window().maximize();
		 }
	  @AfterTest
	  public void afterTest() {
		  //driver.quit();
		  }
	  	
	  
  @Test
  public void q4() {
	  driver.get("http://ataevents.agiletestingalliance.org/");
	  System.out.println(driver.getTitle());
		String PID = driver.getWindowHandle();

	  driver.findElement(By.xpath("/html/body/section/article/div[2]/div[2]/div/a/img")).click();
	  
	  List<WebElement> Links = driver.findElements(By.tagName("a"));
	  System.out.println(Links.size());
	  
	  Set <String>  C_ID = driver.getWindowHandles();
		Iterator<String> it = C_ID.iterator();
		while(it.hasNext())
		{
			String ID = it.next();
			if(ID.equals(PID))
			{
				driver.switchTo().window(ID);
			System.out.println(driver.getTitle());
		
			}
		}

  }
}
