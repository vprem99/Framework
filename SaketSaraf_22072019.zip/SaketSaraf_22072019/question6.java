package CPSAT;

import java.io.FileInputStream;
import java.util.concurrent.TimeUnit;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class question6 {
	WebDriver driver;
	@BeforeTest
	  public void beforeTest() {
		  System.setProperty("webdriver.gecko.driver", ".\\Drivers\\geckodriver.exe");
			driver = new FirefoxDriver();  
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.manage().window().maximize();
		 }
	  @AfterTest
	  public void afterTest() {
		  //driver.quit();
		  }
	  	
	  
  @Test
  public void f() {
	  driver.get("http://www.onlineconversion.com/length_common.htm");
		try {
			FileInputStream IP = new  FileInputStream("C:\\Users\\vshadmin\\Desktop\\data.xlsx");
			XSSFWorkbook wb= new XSSFWorkbook(IP);
			XSSFSheet s=wb.getSheet("Sheet1");
				
			String first=s.getRow(0).getCell(0).toString();
			driver.findElement(By.name("what")).sendKeys(first);
			new Select(driver.findElement(By.name("from"))).selectByVisibleText("kilometer");
			new Select(driver.findElement(By.name("to"))).selectByVisibleText("meter");
			driver.findElement(By.name("Go")).click();
			System.out.println(driver.findElement(By.name("answer")).getAttribute("value"));
			
			String second=s.getRow(1).getCell(0).toString();
			driver.findElement(By.name("what")).clear();
			driver.findElement(By.name("what")).sendKeys(second);
			new Select(driver.findElement(By.name("from"))).selectByVisibleText("feet");
			new Select(driver.findElement(By.name("to"))).selectByVisibleText("inch");
			driver.findElement(By.name("Go")).click();
			System.out.println(driver.findElement(By.name("answer")).getAttribute("value"));
			
			
			String third=s.getRow(2).getCell(0).toString();
			driver.findElement(By.name("what")).clear();
			driver.findElement(By.name("what")).sendKeys(third);
			new Select(driver.findElement(By.name("from"))).selectByVisibleText("meter");
			new Select(driver.findElement(By.name("to"))).selectByVisibleText("kilometer");
			driver.findElement(By.name("Go")).click();
			System.out.println(driver.findElement(By.name("answer")).getAttribute("value"));
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
  }
}
